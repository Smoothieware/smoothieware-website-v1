---
status: v01-rendered-unqualified-review
priority: requested
gadgeteer_socket_types: [Y]
reserved_by: null
designed_by: null
reference_url: https://www.adafruit.com/product/1609
source_section: "Maintainer request, 2026-10-04; new board, not historical breadboard-board"
license: CERN-OHL-S-2.0
---

# Gadgeteer perma-proto breadboard

A solderable half-size breadboard PCB with a keyed Gadgeteer connector at its centre. This is a new board, distinct from `breadboard-board`. Manufacture in KiCad, under CERN OHL. Build **one revision, v01**, render it and request maintainer review; the usual multiple-version process does not apply to this explicit request.

## Breadboard behaviour and appearance

- Thirty numbered columns on a 2.54 mm grid. Each upper column has five holes A–E electrically joined; each lower column has five holes F–J joined. Adjacent columns and opposite halves are isolated unless explicitly mapped below. Parts are soldered, not spring-contact inserted.
- Four uninterrupted 30-hole horizontal rails: upper +5 V and GND; lower +3.3 V and GND. Both ground rails are joined to Gadgeteer pin 10. Positive rails are never joined.
- 1.2 mm plated prototype holes with 2.0 mm round lands, gold finish (ENIG), white solder mask and black readable legends. The bottom five-hole links and rail buses have deliberately exposed copper, like the reference, to permit cutting. Front legends outline connected strips and mark rail polarity, voltage, coordinates and signal mapping. No copied Adafruit logo or claim of affiliation.
- A widened middle channel accommodates the keyed connector without covering any prototyping hole. Centre seven columns are 12–18, left to right.

## Exact connector mapping

Use canonical Gadgeteer Version 16, type Y: pin 1 = +3.3 V, pin 2 = +5 V, pins 3–9 = seven GPIO, pin 10 = GND. Header viewed from above, notch south: even pins along north, odd pins along south, pin 1 southwest. The requested “1 up, 2 down” refers to **signal index**, not physical pin number (physical pins 1 and 2 are power).

| Signal index | Physical pin | Destination |
|---|---|---|
| 1 | 3 | Upper A–E, column 12 |
| 2 | 4 | Lower F–J, column 13 |
| 3 | 5 | Upper A–E, column 14 |
| 4 | 6 | Lower F–J, column 15 |
| 5 | 7 | Upper A–E, column 16 |
| 6 | 8 | Lower F–J, column 17 |
| 7 | 9 | Upper A–E, column 18 |
| Power | 1 | Lower +3.3 V rail |
| Power | 2 | Upper +5 V rail |
| Return | 10 | Both GND rails |

## Electrical boundaries

Entirely passive copper breakout: no level conversion, buffers, pull-ups, regulators or firmware. GPIO remains native host 3.3 V logic and is not certified 5 V tolerant. Host supplies all power; do not connect an independent supply to these rails while connected to the host. No hot-plug qualification. User-installed loads must respect the actual host socket/cable budget; v01 provisional total rail-load design/test target is 100 mA per positive rail, subject to a lower host/cable limit. GPIO limits come from the actual host, not PCB track capacity. The unprotected host-connected pads are for low-voltage bench prototyping only.

## Deliberate deviations

One central connector, no daisy-chain connector: preserves the explicitly requested breadboard area and central layout. Type Y only; no built-in Gadgeteer I²C function, optional I²C mode or configurable socket. A user who builds an I²C circuit must provide Qwiic access on that circuit under the family rule; this PCB does not implement that bus. This does not certify arbitrary later user circuits. No external 12–24 V input. No high-current/mains use.

## Source and qualification questions

Reference: [Adafruit 1609](https://www.adafruit.com/product/1609) publishes 30 double five-hole rows, four rails, 1.2 mm drills, plated holes and exposed bottom copper. Its 81 × 51 mm envelope is inspirational; ours is 86 × 64 mm to accommodate the header.

Actual cable keying/mating fit, supplier tolerances, hand-solder/rework tests, host current allocation, electrical continuity and physical checks remain first-article qualifications. All 132 schematic/layout checklist items require per-v01 evidence; failed or unverified items block signoff. Reviewable rendered v01 does not imply fabrication release.

## Authorized group3 prototype revisions — 2026-10-11

The current request authorizes meaningful retained successors through v10 or later. Historical draft/version restrictions above remain historical records. The version-local frozen contract and its exact native CAD govern each prototype; these choices do not resolve unavailable physical evidence.

Named target: **Passive central canonical Gadgeteer Y breakout with60five-hole strips and four30-hole rails**.

Keep all420 prototype/rail holes at2.54mm pitch,1.2mm plated drills, central keyed Samtec header and two netless M3 holes80mm apart. Preserve alternating physical pins3–9 to centre columns12–18 and unique cuttable bottom links. The successor outline target is86×62mm with2mm corners, family black mask and white silk. Use host power only; provisional100mA per positive rail, lower host/cable limits prevail. No controller or automatic I²C mode is added.

Inspect `attempt/versions.json` and each version’s `completion.json`/132-item review for actual generated and checked state. Independent final review, supplier capability, actual host/cable fit, physical tests and checklist signoff remain explicit gates. `attempt/component-reuse-review.json` records the IC opportunity decision and exact stock-source evidence/limits; matching value alone is not confirmed stock.

## Independent geometry and assembly disposition — 2026-10-11

Saved v11 Edge.Cuts centreline extrema are (0,0) to (86,62) mm: nominal86 ×62 mm. The0.05 mm outline stroke produces the86.05 ×62.05 mm rendered/bounding-box measurement; it does not enlarge the manufacturing centreline. No board resize was made.

“Half-size Perma-Proto” describes inspiration from30 columns and split five-hole groups. This custom outline,80 mm mounting pitch and widened keyed-header centre channel are not a dimensional or mechanical drop-in replacement claim. Ordinary DIP packages need jumper bridges. The populated view models the single fitted BOM componentJ1; maker-added parts, solder, DIP packages and cables have no fit qualification. Inlet fuse/reverse protection, inlet TVS and GPIO ESD remain absent (S010/S011/S052 fail). See [review disposition](attempt/independent-review-disposition.json).


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain passive solderable strips/rails; no exact stocked connector match or justified IC addition. Preserve v11; no new version. Current selected v11; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v11**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: preserve incompatible/non-3/4-pin interfaces listed in local record; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

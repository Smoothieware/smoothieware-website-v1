# MAX31856 v16 native CAD study

Open attempt/versions/v16/spi-thermocouple.kicad_pro in KiCad 9 with its standard symbol and footprint libraries installed. Extract the entire archive and preserve its directories: the unchanged footprint table resolves ../../footprints/Smoothie_SPI_Thermocouple.pretty relative to the v16 project. Review.kicad_sym and both child schematic sheets are included. Standard KiCad libraries are external editing dependencies. Native PCB footprint geometry and schematic cached symbols remain included.

This is the selected v16 package for MAX31856, not the older MAX31855 specification proposal. Its PCB title block still says v11 and the schematic title blocks say WIP and UNFINISHED - NOT FOR FABRICATION. These native files are unchanged. The package is an unqualified CAD study, not a fabrication release, assembly instruction or evidence of a working firmware driver. MAX31856 and MAX31855 protocols/configurations are not interchangeable.

The retained schematic PDF, netlist, BOM and placement files are original study exports, not newly qualified manufacturing outputs. Only absolute originating directory prefixes in the XML netlist are normalized; electrical content is unchanged. MANIFEST.json records original and distributed hashes. No fabrication outputs or render caches are included.

The specification releases the hardware under CERN OHL; the design repeats that requirement and all three schematic sheets declare Smoothieware / CERN-OHL-S-2.0. The PCB has no separate title-block license declaration. License texts and KiCad library attribution/exception are included for the source study and library-derived material. Manufacturer identification does not establish endorsement or fitted connector compatibility.

Optional 3D models are intentionally omitted because redistribution permission for all external assets is unestablished. Native model references are unchanged. The 2D project remains editable; the 3D viewer can report missing models or omit those bodies. Standard KiCad 3D libraries can resolve standard references if separately installed. The local Samtec VRML body is not included. This is not a complete 3D assembly package.

Optional model references:
- `${KICAD9_3DMODEL_DIR}/Capacitor_SMD.3dshapes/C_0603_1608Metric.step`
- `${KICAD9_3DMODEL_DIR}/Package_SO.3dshapes/TSSOP-14_4.4x5mm_P0.65mm.step`
- `${KICAD9_3DMODEL_DIR}/Resistor_SMD.3dshapes/R_0603_1608Metric.step`
- `${KICAD9_3DMODEL_DIR}/TerminalBlock_Phoenix.3dshapes/TerminalBlock_Phoenix_PT-1,5-2-3.5-H_1x02_P3.50mm_Horizontal.step`
- `${KIPRJMOD}/../../models/Samtec_SHF105_TH_LC.wrl`

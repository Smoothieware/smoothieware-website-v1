# SPI thermocouple breakout design

## Design status

Status: **draft**. This document implements [specs.md](specs.md) where the evidence is sufficient and leaves design-blocking values explicit. The PCB must be authored in KiCad only and released under CERN OHL.

## Architecture from scratch

A single MAX31855K conversion cell sits at the thermocouple connector; it returns read-only SPI data and passes the shared bus through cuttable chain links.

## Text block diagram

```text
K THERMOCOUPLE → 10 nF/filter → MAX31855K → MISO
S: SCK/CS/rails → converter; all S nets → jumpers → S CHAIN
```

## Circuit and component decisions

- MAX31855K with exact orderable suffix TBD.
- 0.1 µF ceramic at VCC and 10 nF ceramic across T+/T−.
- Route T+/T− symmetrically and keep copper transitions isothermal.

## Gadgeteer pin mapping

The table below uses the repository-canonical connector rule: pin 1 is +3.3 V, pin 2 is +5 V, and pin 10 is GND. **Do not release a schematic from this table until it is reconciled pin-by-pin with the current V2 Prime connector implementation; current web documentation presents a conflicting ordering.**

|  Pin | Function          | Design note                                                        |
| ---: | ----------------- | ------------------------------------------------------------------ |
|    1 | +3.3 V            | Canonical fixed rail.                                              |
|    2 | +5 V              | Canonical fixed rail.                                              |
|    3 | GPIO!/DRDY unused | Board mapping; validate against current V2 hardware before layout. |
|    4 | GPIO unused       | Board mapping; validate against current V2 hardware before layout. |
|    5 | GPIO unused       | Board mapping; validate against current V2 hardware before layout. |
|    6 | CS                | Board mapping; validate against current V2 hardware before layout. |
|    7 | MOSI pass-through | Board mapping; validate against current V2 hardware before layout. |
|    8 | MISO              | Board mapping; validate against current V2 hardware before layout. |
|    9 | SCK               | Board mapping; validate against current V2 hardware before layout. |
|   10 | GND               | Canonical fixed rail.                                              |

## Power budget

| Rail/source | Consumers         | Design allocation                     |
| ----------- | ----------------- | ------------------------------------- |
| 3.3 V       | MAX31855          | Datasheet current plus margin; verify |
| 5 V         | Pass-through only | No local load                         |

No TBD allocation may be converted into a copper width, connector rating, fuse value, or advertised load rating without calculation and test.

## Protection and signal conditioning

Low-capacitance ESD/protection compatible with thermocouple error budget; do not clamp thermocouple inputs with an unvalidated junction.

## PCB stackup and routing

Two layers with a ground plane; thermocouple section isolated thermally from connector rails and digital switching.

## Mechanical envelope and mounting

Small board, thermocouple terminal on one edge, S input/chain opposite; two ungrounded M3 holes if 20 mm grid fits.

## Connector placement

MAX31855 adjacent to thermocouple terminal; no regulator, LED, or high-current trace near cold junction.

## Chaining and solder jumpers

Per-pin cuttable links; default pass-through. Converter uses CS/MISO/SCK/3.3 V/GND only.

## Silkscreen

K-TYPE +/−, S, IN/CHAIN, CS identity, no-hot-plug note, version, logo, CERN OHL.

Every production board must also identify the socket type/profile, board revision, connector polarity/pin 1, and CERN OHL licence.

## Verification plan

- Read known thermocouple points and ambient cold-junction conditions.
- Inject open and short faults.
- Verify SPI timing alone and through hub.
- Measure self-heating and gradient-induced error.

## Edge cases and failure modes

- Reversed thermocouple.
- Open sensor.
- Multiple devices driving MISO.
- Hot terminal or airflow across cold junction.

## Decisions blocked before KiCad

- Current firmware support and CS mapping.
- Exact converter suffix/connector.
- Accuracy budget.

## Selected CAD prototype and component review (2026-10-11)

The retained v03 contract defines the concrete prototype scope below. This supersedes the historical pre-CAD blockers for study generation; physical host/cable, supplier and bench qualification remain open. No fabrication release is claimed.

One MAX31855K reads one K-type thermocouple on a 2-position 3.5 mm screw terminal and returns 32-bit read-only SPI data (thermocouple and cold-junction temperature, OC/SCG/SCV fault bits) on S-socket MISO. A second S socket passes the bus through for chaining or use with the SPI hub.

The repository-canonical pin 1 = 3.3 V, pin 2 = 5 V, pin 10 = GND contract is used. Actual host marking, mating face and cable continuity must be checked before connection. The host 5 V regulator capacity is shared across the platform.

IC opportunities were reviewed in `docs/ic-opportunities.html`; decisions and BOM-source hashes are in `attempt/component-selection-20261011.json`. MAX31856: deferred; Adds programmable thermocouple types/register driver; the requested K-type read-only SPI target and current driver are retained. Cold-junction error still requires physical testing. AD8495: declined; Analogue ADC interface loses specified digital fault reporting and changes Gadgeteer S contract.

Prefer matching stocked Smoothieboard v1 0603 100 nF/50 V bypass capacitors and 0603 10 kΩ bias resistors after the actual rating, dielectric and tolerance check. V2 0402 passives require a deliberate new land pattern. Existing specialized ICs and protection parts remain specified unless a verified new contract changes them.

## Current native reconciliation (2026-10-11)

Selected **v11** reaches the original minimum-v10 program. Two existing ordinary GND vias move 0.20 mm away from U1 lands, with attached track endpoints retargeted. This removes both expanded-mask contacts missed by native DRC. MAX31855K and K-type SPI behavior are retained; MAX31856 remains a separate firmware/package redesign and AD8495 changes the interface to analogue. Fresh retained ERC, strict geometry, opens and schematic parity are zero; actual-shape via/pad/mask screening is clear. Six own-version views were inspected and all package hashes match. Earlier revision discussions above remain historical. Physical host/cable, thermal, EMC, supplier and fabrication qualification are unsigned; 130 of 132 checklist items remain unverified. Full 270-rule inventories are supplemental inventories, not signoff.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain MAX31855K; defer MAX31856; decline AD8495; conditional V1 C0603 bypass reuse; no new version Current selected v11; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v11**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: preserve incompatible/non-3/4-pin interfaces listed in local record; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.


## Programmable thermocouple variant v15 — 2026-10-13

A new additive **MAX31856MUD+** native KiCad candidate is retained in [v15](attempt/versions/v15/). It is a distinct read/write SPI variant; historical MAX31855K revisions and their read-only driver contract remain retained. The 40 × 30 mm board preserves the S input/chain pinout, all seven chain jumpers, default open chain-CS link, 10 kΩ CS pull-up, terminal and mounting. It replaces U1 with TSSOP-14 and adds three capacitors: independent AVDD/DVDD 100 nF bypasses, 100 nF differential filtering and matched 10 nF common-mode filters. Eight programmed thermocouple types and 50/60 Hz rejection become available.

The host must configure the thermocouple type, noise filter, conversion mode and fault policy through MOSI/register writes; no firmware was modified or verified. Supply is 3.0–3.6 V, 2 mA maximum converter active current plus about 0.33 mA CS pull-up while selected; 5 V is pass-through only. Host current allocation and thermal gradients between terminal and IC remain unqualified. Native electrical/track/connectivity/parity and declarative pin/value/footprint checks pass with no findings or ignored rule severities. Candidate manufacturing files do not authorize fabrication.

See [the v15 engineering record](attempt/versions/v15/ENGINEERING.md) and [actual electrical contract](attempt/versions/v15/design-contract.json) for BOM, package comparison, per-check acceptance and inherited family limits. Earlier statements that MAX31856 is deferred describe the historical K-only variant and do not select this new driver automatically.

---
status: draft
priority: unspecified
gadgeteer_socket_types: [S]
reserved_by: null
designed_by: "Samuel House"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/Thermocouple"
source_section: "data/extracted/spec.txt:268-280"
---

# SPI thermocouple breakout specifications

## Purpose

Measure one K-type thermocouple with a cold-junction-compensated SPI converter.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Read one thermocouple.
- Use four boards through the separately qualified SPI hub.

## Functional requirements

- Use a K-suffix MAX31855 device unless firmware evidence selects another converter.
- Expose polarized thermocouple terminals and an S input/chain pair.
- Keep the cold junction away from heat-generating parts and airflow gradients.
- Report open/short thermocouple faults through SPI.

## Inputs

- K-type thermocouple on 3.5 mm terminal.
- S Gadgeteer SPI and rails.

## Outputs

- Read-only SPI MISO data and one chained S port.

## Electrical requirements

- MAX31855 operates from 3.0–3.6 V; use 3.3 V only.
- Fit 0.1 µF VCC bypass and 10 nF differential T+/T− capacitor per datasheet.
- MOSI is carried by S but unused by MAX31855.

## Optional features

- None until thermal error budget and bus behavior are proven.

## Constraints and exclusions

- Footnote [m] leaves chip/firmware relevance open; footnote [n] confirms only historical V1 support.
- K-type connector polarity and alloy transition location affect accuracy.

- The current task includes versioned native KiCad prototypes and manufacturing exports. Firmware implementation and physical qualification are separate stages.

## Open questions

- Verify current SmoothieV2 MAX31855 support, SPI mode/rate, and CS allocation.
- Choose exact MAX31855K package/suffix and thermocouple connector.
- Set accuracy and ambient-gradient acceptance limits.

## Source amendments and local evidence

- Footnote [m]: are we swapping chips? is this implemented/relevant to firmware?
- Footnote [n]: This is supported by v1
- No board-specific image tag occurs in the extracted source section.

## Prior art and evidence

- Samuel House Thermocouple design.
- Analog Devices MAX31855 product page and datasheet cited in research.md.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.

## Selected CAD prototype and component review (2026-10-11)

The retained v03 contract defines the concrete prototype scope below. This supersedes the historical pre-CAD blockers for study generation; physical host/cable, supplier and bench qualification remain open. No fabrication release is claimed.

One MAX31855K reads one K-type thermocouple on a 2-position 3.5 mm screw terminal and returns 32-bit read-only SPI data (thermocouple and cold-junction temperature, OC/SCG/SCV fault bits) on S-socket MISO. A second S socket passes the bus through for chaining or use with the SPI hub.

The repository-canonical pin 1 = 3.3 V, pin 2 = 5 V, pin 10 = GND contract is used. Actual host marking, mating face and cable continuity must be checked before connection. The host 5 V regulator capacity is shared across the platform.

IC opportunities were reviewed in `docs/ic-opportunities.html`; decisions and BOM-source hashes are in `attempt/component-selection-20261011.json`. MAX31856: deferred; Adds programmable thermocouple types/register driver; the requested K-type read-only SPI target and current driver are retained. Cold-junction error still requires physical testing. AD8495: declined; Analogue ADC interface loses specified digital fault reporting and changes Gadgeteer S contract.

Prefer matching stocked Smoothieboard v1 0603 100 nF/50 V bypass capacitors and 0603 10 kΩ bias resistors after the actual rating, dielectric and tolerance check. V2 0402 passives require a deliberate new land pattern. Existing specialized ICs and protection parts remain specified unless a verified new contract changes them.

## Current native reconciliation (2026-10-11)

Selected **v11** reaches the original minimum-v10 program. Two existing ordinary GND vias move 0.20 mm away from U1 lands, with attached track endpoints retargeted. This removes both expanded-mask contacts missed by native DRC. MAX31855K and K-type SPI behavior are retained; MAX31856 remains a separate firmware/package redesign and AD8495 changes the interface to analogue. Fresh retained ERC, strict geometry, opens and schematic parity are zero; actual-shape via/pad/mask screening is clear. Six own-version views were inspected and all package hashes match. Earlier revision discussions above remain historical. Physical host/cable, thermal, EMC, supplier and fabrication qualification are unsigned; 130 of 132 checklist items remain unverified. Full 270-rule inventories are supplemental inventories, not signoff.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain MAX31855K; defer MAX31856; decline AD8495; conditional V1 C0603 bypass reuse; no new version Current selected v11; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v11**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: preserve incompatible/non-3/4-pin interfaces listed in local record; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.


## Programmable thermocouple variant v15 — 2026-10-13

A new additive **MAX31856MUD+** native KiCad candidate is retained in [v15](attempt/versions/v15/). It is a distinct read/write SPI variant; historical MAX31855K revisions and their read-only driver contract remain retained. The 40 × 30 mm board preserves the S input/chain pinout, all seven chain jumpers, default open chain-CS link, 10 kΩ CS pull-up, terminal and mounting. It replaces U1 with TSSOP-14 and adds three capacitors: independent AVDD/DVDD 100 nF bypasses, 100 nF differential filtering and matched 10 nF common-mode filters. Eight programmed thermocouple types and 50/60 Hz rejection become available.

The host must configure the thermocouple type, noise filter, conversion mode and fault policy through MOSI/register writes; no firmware was modified or verified. Supply is 3.0–3.6 V, 2 mA maximum converter active current plus about 0.33 mA CS pull-up while selected; 5 V is pass-through only. Host current allocation and thermal gradients between terminal and IC remain unqualified. Native electrical/track/connectivity/parity and declarative pin/value/footprint checks pass with no findings or ignored rule severities. Candidate manufacturing files do not authorize fabrication.

See [the v15 engineering record](attempt/versions/v15/ENGINEERING.md) and [actual electrical contract](attempt/versions/v15/design-contract.json) for BOM, package comparison, per-check acceptance and inherited family limits. Earlier statements that MAX31856 is deferred describe the historical K-only variant and do not select this new driver automatically.

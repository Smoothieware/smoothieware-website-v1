---
status: blocked
priority: unspecified
gadgeteer_socket_types: []
reserved_by: null
designed_by: "Ray Kholodovsky, Bob Cousins"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/Large%20MOSFET_kicad"
source_section: "data/extracted/spec.txt:227-246"
---

# Single-Channel Large MOSFET output specifications

## Purpose

Switch one 5–24 V high-current DC load with a qualified continuous rating of at least 12.5 A.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Control a heated bed, large heater, fan bank, or qualified solenoid.

## Functional requirements

- Accept only logic from the upstream Ground/Power/Signal connector; load energy comes from the dedicated power input.
- Use a low-side MOSFET with safe-off gate bias and suitable drive.
- Provide flyback suppression for qualified inductive loads.
- Use four PCB layers for heat spreading and current distribution.

## Inputs

- One keyed 2.54 mm logic connector.
- One dedicated 5–24 V high-current DC input.

## Outputs

- One dedicated high-current load connector.

## Electrical requirements

- 12.5 A minimum continuous target requires a stated ambient, airflow, copper weight, and temperature-rise limit.
- Upstream connector power must not feed the load.
- The saved candidate selects XT30PW connectors following footnotes [i]/[j]. Their current rating, mating polarity and temperature rise still require qualification of the assembled board.

## Optional features

- Buffered status LED.

## Constraints and exclusions

- Footnote [h] requires full review and imports small-board silk/layout concerns.
- Four layers are mandatory.
- DC only; no mains.

- Hardware scope only; retained KiCad revisions and CAM are review candidates, with no firmware change or fabrication release.

## Open questions

- Qualify the selected XT30 connectors and complete the protection coordination for the selected components.
- Define thermal acceptance conditions.

## Current saved candidate

[v12 contract](attempt/versions/v12/design-contract.json): 74 × 49 mm, four layers, 2 mm corner radius, four unchanged M3 mounting datums. Selected parts are CSD18536KTT MOSFET, UCC27517ADBVR driver, MBRB20H60CT flyback diode, SMDJ28A TVS and CB61F 20 A fuse. J1 is a three-pin Ground/Power/Signal header; this board has no Gadgeteer socket.

The original ≥12.5 A continuous requirement remains unqualified. A 20 A fuse does not establish protection of the connector rated 15 A; the raw-input TVS is upstream of that fuse, and reverse-polarity fault interruption is unproven. The original 60 mm width target is unmet. [Component reuse review](attempt/component-reuse-review.md) records V1 header and capacitor-family reuse and the IC opportunity assessment. Stock quantities and capacitor lot properties are unverified.

## Source amendments and local evidence

- Footnote [h]: Hmmm ... I dunno about this one. I need to review this. Otherwise same comments as small mosfet above.
- Footnote [i]: XT30
- Footnote [j]: XT30 yes. and if this means we can get more out of the mosfet : different current rating.
- Tagged source figure: [Large MOSFET.png](../../data/extracted/images/image12.png)

## Prior art and evidence

- Historical Large MOSFET KiCad design and tagged Large MOSFET.png.
- Smoothieware low-side MOSFET guidance.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain UCC27517A/CSD18536 single low-side output;TPS274C65 high-side four-channel part changes target. Existing V1 Molex J1 and C2/C3 bypass reuse retained,no successor. Current selected v12; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v12**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: compact PH/SH alternatives at J1; audit fuse references F1 and power-entry candidates J1, J2; independently disable existing LEDs D3, D4, R5, R6. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

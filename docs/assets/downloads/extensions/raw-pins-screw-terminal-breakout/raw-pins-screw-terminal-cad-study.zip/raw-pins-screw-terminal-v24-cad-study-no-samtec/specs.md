---
status: draft
priority: unspecified
gadgeteer_socket_types: [Y]
reserved_by: null
designed_by: "Bob Cousins"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/BreakoutTerm"
source_section: "data/extracted/spec.txt:146-154"
---

# Raw pins screw terminal breakout specifications

## Retained prototype amendment: v17

Current inspection prototype:46×32 mm passive Y terminal/chain adapter, same-host populated Qwiic, and seven conditional LRC LESD8D3.3CAT5G SOD-882 shunts. This supersedes the historical unprotected draft below; it does not add level shifting, buffering or a controller. [Selected package and component decisions](attempt/README.md), [comparison](attempt/revision-comparison.md) and [parent review](attempt/parent-review-v17.json) are authoritative for the retained CAD. Both Smoothieboard BOMs were reviewed; the V2 TVS family is conditional, its generic0402 label is not the adopted SOD-882 land pattern, and no stock quantity or exact connector reuse is established.

Parent ERC/geometry/parity0 with **five opens**;22 references/68 pins,11 fitted BOM/position lines and106 selected package hashes match. v16 preserved routed v14 while fixing two ground-thermal findings; v17 corrects schematic note/title overlap without changing copper. Native-to-Excellon133-hole counts match; all six views, schematic and actual two-face CAM inspected. Endpoint paths, seven same-net conservative mask contacts, solid-pad solder heating/wetting, actual host/cable/current limits, supplier/model/wire/tool fit and physical/system ESD qualification remain unresolved. No fabrication release.

## Purpose

Passively expose all ten Y-socket contacts on individually accessible 3.5 mm screw terminals.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Field-wire sensors or experiments without crimping.
- Retain a downstream Y port while inspecting individual nets.

## Functional requirements

- Provide ten terminals in canonical pin order and one chained Y connector.
- Preserve every signal without level shifting, filtering, pull-ups, or termination.
- Print net name, pin number, and rail warning beside each terminal.

## Inputs

- One canonical Y Gadgeteer port.

## Outputs

- Ten 3.5 mm screw-terminal positions and one parallel Y chain port.

## Electrical requirements

- Current is limited by the weakest Gadgeteer connector, cable, PCB trace, and terminal; terminal pitch is not a power-rating upgrade.
- Select terminals accepting the documented wire range only after supplier validation.

## Optional features

- Individual cuttable links between input and chain.

## Constraints and exclusions

- Footnote [b] imports the Raw pins breakout requirements: Y, licence, version, logos.
- Maintain one-to-one pin order despite different connector geometries.

- This repository specifies hardware only: no firmware changes and no KiCad deliverables are included at this stage.

## Open questions

- Choose exact 3.5 mm terminal and wire-entry orientation.
- Confirm whether the chain needs ten cuttable links.

## Source amendments and local evidence

- Footnote [b]: Same comments as "Raw pins breakout"
- Tagged source figure: [BreakoutTerm.png](../../data/extracted/images/image9.png)

## Prior art and evidence

- Bob Cousins BreakoutTerm design and tagged BreakoutTerm.png.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.

## Current revision requirements (2026-10-11)

The historical specification above is retained. Versioned native KiCad design work is now in scope. The selected screw terminal is Phoenix Contact 1984691 (10-pole, 3.5 mm); the two keyed adapter-side connectors are Samtec SHF-105-01-L-D-TH-LC. These choices do not prove physical host/cable mating. Nine cuttable links affect only chain pins 1–9; GND remains continuous.

Configurable I²C on host P9/SDA and P8/SCL requires a populated same-bus 3.3 V Qwiic connector in the successor design. Disconnect Qwiic devices when P8/P9 serve other functions. No 5 V, independent supply, duplicate pullups or second host may be applied to Qwiic. All rail current allocations remain unresolved until the host, cable and connectors are qualified.

Review IC opportunities and exact Smoothieboard V1/V2 stock parts for every successor; record adopted and rejected candidates. Do not change raw-contact voltage/function simply to reuse a stocked IC.

Conditional stock protection from v12: seven exact LRC LESD8D3.3CAT5G SOD-882 shunts on terminal P3–P9. Restrict to qualified low-speed 3.3 V signaling; capacitance, temperature leakage, host survival and unpowered behavior remain qualification gates. Exact stock manufacturer/lot verification is required; the V2 generic 0402 label is not a footprint authority.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain passive terminal access and populated same-bus Qwiic; seven conditional V2 LRC SOD882 shunts already added v12. No spare active function or exact connector substitution justified;retain v17,no successor. Current selected v17; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v17**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: compact PH/SH alternatives at J4; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

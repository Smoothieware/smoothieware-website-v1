---
status: blocked
priority: unassigned
gadgeteer_socket_types: ["A"]
reserved_by: "Jon Thore Myklatun"
designed_by: null
reference_url: null
source_section: "data/extracted/spec.txt:615-629"
---

# Simple PT100 amplifier board specifications

## Retained prototype amendment — v14

IC upgrade and Smoothieboard BOM reuse decisions: [IC and stock review](component-review.md).

The retained analogue study uses OPA2333AID and BSS84 with the authored precision excitation/amplifier network. D2 uses exact Smoothieboard V2P12 BOM Id27 TPD4E1U06DCKR fromv06, with TI DCK lands and unchanged protection-channel pin mapping. The IC guide ADS1220/ADS124S08 opportunity changes the analogue A-socket interface to digital transport and requires a deliberate excitation/reference/firmware design. Precision resistors retain their authored0.1% choices; generic V1 resistor tolerances are not equivalent.

Selected v14 is40x35.6mm with mounting centers(5,30)/(35,30)mm, preserving30mm pitch. These actual datums supersede inherited placement fields. V03–v10 restore ground returns, widen force-current branches and repair the local TVS return; rejected attempts remain retained. Strict native DRC/parity are0, with2 ground connections still open. An actual-shape drill/ring/mask-to-SMD screen finds0 overlaps. V11/v13 reconcile local symbol associations and library schema; v12/v14 fit the schematic and title inside A2. Fresh parent v14 confirms ERC0/DRC0/opens2/parity0,99 pin identities,99 matching package hashes and zero actual via drill/ring/mask-to-land overlaps. Own v03–v14 inspection packages are complete; calibration, lead compensation, sense/force pairing, analogue-zone routing, ADC/host limits, supplier assembly and physical qualification remain unsigned. The historical requirements and unresolved choices below remain applicable.


## Purpose

Condition one PT100 RTD into a bounded analogue voltage for a Smoothieboard analogue input.

## Use cases

- Single low-cost PT100 measurement when accuracy requirements permit an analogue front end.

## Functional requirements

- Excite the PT100 at a current that avoids self-heating.
- Map the required temperature range into the verified ADC range.
- Support a declared 2-, 3- or 4-wire arrangement.
- Correct source contradictions: use A, not S or O, and label RTD rather than K-type thermocouple.

## Inputs

- PT100 terminal, wire count TBD.
- 3.3/5 V supply and analogue connection from one A socket.

## Outputs

- One filtered analogue voltage to AIN.
- Optional duplicated 2.54 mm analogue test output only if protected.

## Electrical requirements

- PT100 is 100 ohms at 0 °C; lead resistance must be included.
- Excitation, gain, offset, reference and ADC limits are unresolved.
- The source's pin-shifting chain is forbidden because it would move fixed rails/ground.

## Optional features

- Calibration test points and wire-mode jumpers.

## Constraints and exclusions

- No unsafe shifted-pin daisy chain.
- No thermocouple compatibility.
- CERN OHL; KiCad only.
- The hardware design and generated manufacturing data must be created in KiCad only.
- The board must be released under CERN OHL.

## Open questions

- Temperature range/accuracy.
- Wire count and maximum lead resistance.
- Current-source and amplifier topology.
- Actual V2 ADC range/reference.

## Source amendments and local evidence

- No board-specific maintainer footnote occurs in the extracted source section.
- No board-specific image tag occurs in the extracted source section.

## Prior art and evidence

- Historical reservation by Jon Thore Myklatun.
- MAX31865 datasheet provides PT100 lead-compensation background but is not this analogue circuit.
- The historical source and all maintainer amendments are preserved in research.md.
- The repository canonical connector table is authoritative for this draft, but the current V2 Prime documentation exposes a conflicting physical pin description; physical compatibility is blocked until that discrepancy is resolved.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain OPA2333AID/BSS84 analogue contract and precision network; defer digital ADC as architecture change; use exact V2 DCK ESD array and only electrically/package-matched stock passives; no new version. Current selected v14; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v14**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: preserve incompatible/non-3/4-pin interfaces listed in local record; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

# Servo Board v18 — unqualified native CAD study

Open servo-out.kicad_pro with KiCad 9 and the standard KiCad 9 symbol and footprint libraries installed. Keep this directory together: the library tables use ${KIPRJMOD} for the included custom symbols and footprints. The PCB stores its footprint geometry and the schematic stores cached symbols. Standard editing libraries remain external dependencies, not missing files from this download.

This is the selected v18 source package, not a fabrication or hardware release. Its PCB title block still says v17, its silkscreen says V18, and its schematic title block says v10. These original native files are unchanged. The guide's channel-one rear-pad/JP2 variant is a separate wiring proposal, not an alteration already applied to these CAD sources. Native defaults do not prove assembly continuity or operating limits.

Contents include the native project, PCB, schematic and design rules; local library tables, symbols and footprints; retained schematic PDF, netlist, BOM and placement exports; and specification/design/component-review source documents. Exports are retained source-study outputs, not a newly verified fabrication set. No Gerbers or production-ready claim is included. The netlist's originating absolute project directory is changed only to a relative filename; electrical entries are unchanged. MANIFEST.json records original and distributed hashes.

Licensing: the native PCB and schematic declare Smoothieware / CERN-OHL-S-2.0, and the specification/design require CERN OHL. The included project-authored sources follow that declaration. KiCad-derived library material retains CC-BY-SA-4.0 with the KiCad library exception; the corresponding texts are included in LICENSES. Custom connector footprints describe source geometry; manufacturer names do not confer approval or a physical mating qualification.

Optional 3D models are intentionally omitted. Redistribution permission for all third-party model assets has not been established. Native model references remain unchanged. KiCad's 2D PCB and schematic remain editable; the 3D viewer may report missing models or omit those bodies. Installing standard KiCad 3D libraries can resolve standard references; local model references remain unavailable unless separately obtained from an authorized source. This is not a complete 3D assembly package.

Optional model references:
- `${KICAD9_3DMODEL_DIR}/Capacitor_SMD.3dshapes/C_0603_1608Metric.step`
- `${KICAD9_3DMODEL_DIR}/Capacitor_SMD.3dshapes/C_0805_2012Metric.step`
- `${KICAD9_3DMODEL_DIR}/Diode_SMD.3dshapes/D_SOD-323.step`
- `${KICAD9_3DMODEL_DIR}/LED_SMD.3dshapes/LED_0805_2012Metric.step`
- `${KICAD9_3DMODEL_DIR}/Package_SO.3dshapes/MSOP-10_3x3mm_P0.5mm.step`
- `${KICAD9_3DMODEL_DIR}/Package_SO.3dshapes/PowerPAK_SO-8_Single.step`
- `${KICAD9_3DMODEL_DIR}/Package_TO_SOT_SMD.3dshapes/SOT-23.step`
- `${KICAD9_3DMODEL_DIR}/Resistor_SMD.3dshapes/R_0603_1608Metric.step`
- `${KICAD9_3DMODEL_DIR}/Resistor_SMD.3dshapes/R_1206_3216Metric.step`
- `${KICAD9_3DMODEL_DIR}/Resistor_SMD.3dshapes/R_2512_6332Metric.step`
- `${KICAD9_3DMODEL_DIR}/TerminalBlock_Phoenix.3dshapes/TerminalBlock_Phoenix_PT-1,5-2-3.5-H_1x02_P3.50mm_Horizontal.step`
- `${KIPRJMOD}/../../models/Fuse_451_2410.wrl`
- `${KIPRJMOD}/../../models/Samtec_SHF105_TH_LC.wrl`
- `${KIPRJMOD}/models/P5_TPS26600.step`
- `${KIPRJMOD}/models/PowerPAK_SO-8_Single-f036ed2d7a96.step`
- `${KIPRJMOD}/models/asset-0-LED_0603_1608Metric.step`
- `${KIPRJMOD}/models/asset-1-Molex_KK-254_AE-6410-03A_1x03_P2.54mm_Vertical.step`
- `${KIPRJMOD}/models/asset-11-TerminalBlock_Phoenix_PT-1,5-2-3.5-H_1x02_P3.50mm_Horizontal.step`
- `${KIPRJMOD}/models/asset-13-D_SMB.step`
- `${KIPRJMOD}/models/asset-2-R_0805_2012Metric.step`
- `${KIPRJMOD}/models/asset-3-C_0603_1608Metric.step`
- `${KIPRJMOD}/models/asset-4-MF-MSMF110_16X-max-envelope.wrl`
- `${KIPRJMOD}/models/asset-5-Samtec_SHF105_TH_LC.wrl`
- `${KIPRJMOD}/models/asset-6-C_0805_2012Metric.step`
- `${KIPRJMOD}/models/asset-7-SOIC-8_3.9x4.9mm_P1.27mm.step`
- `${KIPRJMOD}/models/asset-8-C_1210_3225Metric.step`
- `${KIPRJMOD}/models/asset-9-R_1206_3216Metric.step`

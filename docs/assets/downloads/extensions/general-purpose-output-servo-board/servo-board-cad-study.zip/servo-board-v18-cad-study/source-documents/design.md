# Additional general purpose outputs breakout / Servo board design

## Design status

Status: **blocked**. This document implements [specs.md](specs.md) where the evidence is sufficient and leaves design-blocking values explicit. The PCB must be authored in KiCad only and released under CERN OHL.

## Architecture from scratch

Use one protected power mux for connector supply and seven identical, independently enabled output-driver cells; configuration must make unsafe 12 V output impossible.

## Text block diagram

```text
Y/P pins 3…9 → 7× BUFFER/DRIVER → 7× G/P/S
5 V upstream ───┐
external 5–12 V ┴→ protected source select → connector POWER
```

## Circuit and component decisions

- Use a non-inverting driver family chosen after voltage/current requirements; do not assume a logic buffer can source 100 mA.
- Fit 10 kΩ pull-down on each output.
- Use reverse-current-blocking source selection and a reset-safe output enable.

## Gadgeteer pin mapping

The table below uses the repository-canonical connector rule: pin 1 is +3.3 V, pin 2 is +5 V, and pin 10 is GND. **Do not release a schematic from this table until it is reconciled pin-by-pin with the current V2 Prime connector implementation; current web documentation presents a conflicting ordering.**

|  Pin | Function | Design note                                                        |
| ---: | -------- | ------------------------------------------------------------------ |
|    1 | +3.3 V   | Canonical fixed rail.                                              |
|    2 | +5 V     | Canonical fixed rail.                                              |
|    3 | OUT_1    | Board mapping; validate against current V2 hardware before layout. |
|    4 | OUT_2    | Board mapping; validate against current V2 hardware before layout. |
|    5 | OUT_3    | Board mapping; validate against current V2 hardware before layout. |
|    6 | OUT_4    | Board mapping; validate against current V2 hardware before layout. |
|    7 | OUT_5    | Board mapping; validate against current V2 hardware before layout. |
|    8 | OUT_6    | Board mapping; validate against current V2 hardware before layout. |
|    9 | OUT_7    | Board mapping; validate against current V2 hardware before layout. |
|   10 | GND      | Canonical fixed rail.                                              |

## Power budget

| Rail/source     | Consumers                            | Design allocation  |
| --------------- | ------------------------------------ | ------------------ |
| 3.3 V           | Input-side logic                     | TBD                |
| Gadgeteer 5 V   | Optional connector source            | Upstream limit TBD |
| External 5–12 V | Connector power and possibly drivers | Total current TBD  |

No TBD allocation may be converted into a copper width, connector rating, fuse value, or advertised load rating without calculation and test.

## Protection and signal conditioning

Reverse polarity and fuse/current limit external input; block backfeed; add output shorts protection and ESD appropriate to cables.

## PCB stackup and routing

Two layers if thermal/current analysis passes; use a ground plane and wide power spine.

## Mechanical envelope and mounting

Seven edge connectors, power terminal, and at least two ungrounded M3 holes on 20 mm grid; satisfy footnote [e].

## Connector placement

Servo headers together with consistent G/P/S orientation; external power and selector at one end; Gadgeteer input/chain opposite.

## Chaining and solder jumpers

Per-pin cuttable links; links must isolate the board's input loading and must not pass an externally elevated rail into Gadgeteer 5 V.

## Silkscreen

SERVO/OUTPUT 1–7, G/P/S, actual signal voltage, supply selection, Y/P, warnings, version, logo, CERN OHL.

Every production board must also identify the socket type/profile, board revision, connector polarity/pin 1, and CERN OHL licence.

## Verification plan

- Test reset/startup and each signal at load.
- Measure output high/low, source/sink current, thermal rise, and short response.
- Test every dual-supply ordering and backfeed case.
- Drive representative qualified servo, SSR, and external-driver loads.

## Edge cases and failure modes

- Servo stall/inrush.
- Both sources present at different voltages.
- Host unpowered while external supply is live.
- Non-PWM Y channel used for a servo.

## Decisions blocked before KiCad

- Supported load/voltage matrix.
- Current V2 pin/timer mapping.
- Output-driver and power-path ratings.


## Current IC/stock reconciliation — 2026-10-11

[Selected v10 review](component-review.md) covers101records/73 purchased identities and four existing V1-compatible0603 bypasses. Retain strong drivers/direct interface,no successor. Signal/servo power, selector/backfeed, surge/PTC, thermal/host/STEP/physical gates remain open.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v10**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: compact PH/SH alternatives at J3, J4, J5, J6, J7, J8, J9; audit fuse references F1, F2, F3, F4, F5, F6, F7, F8, F9 and power-entry candidates J10; independently disable existing LEDs D11, D12, D13, D14, D15, D16, D17, D2. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

---
status: blocked
priority: unspecified
gadgeteer_socket_types: [Y, P]
reserved_by: null
designed_by: "Mikkel Jeppesen"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/level-shifter"
source_section: "data/extracted/spec.txt:183-207"
---

# Additional general purpose outputs breakout / Servo board specifications

## Purpose

Provide seven buffered output channels on servo-style Ground/Power/Signal connectors for servos, SSR inputs, or external driver logic.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Drive hobby servos from PWM-capable channels.
- Drive defined external stepper/SSR logic inputs needing more current than a 3.3 V GPIO.

## Functional requirements

- Provide seven independently buffered signals with at least 100 mA capability only where the chosen driver safely supports it.
- Separate signal-level selection from connector power distribution.
- Select between upstream 5 V and external supply without backfeed.
- Provide Y/P input and chain connectors only after the pin/timer mapping is verified.

## Inputs

- Y or P Gadgeteer signals.
- External 5–12 V power on 3.5 mm terminal.

## Outputs

- Seven keyed 2.54 mm Ground/Power/Signal connectors.
- One chain port.

## Electrical requirements

- Source asks for 5–12 V connector power and 5–12 V signal; that is not a universal servo contract and remains blocked pending a supported-load matrix.
- Signal outputs require 10 kΩ pull-downs under the project standard.
- Total servo inrush can far exceed Gadgeteer power.

## Optional features

- Buffered activity LED per output.

## Constraints and exclusions

- Footnote [e] requires schematic review, finished silk, and at least one more screw hole.
- Do not expose 12 V signal to 5 V-only servos.

- This repository specifies hardware only: no firmware changes and no KiCad deliverables are included at this stage.

## Open questions

- Define supported loads and per-channel signal level/current.
- Confirm seven PWM-capable pins and timers.
- Select power ORing/current limiting and total connector budget.

## Source amendments and local evidence

- Footnote [e]: Need to check schematic, silk unfinished, needs at least 1 more screw hole
- Tagged source figure: [3D-render-top.png](../../data/extracted/images/image2.png)

## Prior art and evidence

- Mikkel Jeppesen level-shifter design and tagged 3D-render-top.png.
- Current V2 GE/TIM15 mapping cited in research.md.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.


## Current IC/stock reconciliation — 2026-10-11

[Selected v10 review](component-review.md) covers101records/73 purchased identities and four existing V1-compatible0603 bypasses. Retain strong drivers/direct interface,no successor. Signal/servo power, selector/backfeed, surge/PTC, thermal/host/STEP/physical gates remain open.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v10**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: compact PH/SH alternatives at J3, J4, J5, J6, J7, J8, J9; audit fuse references F1, F2, F3, F4, F5, F6, F7, F8, F9 and power-entry candidates J10; independently disable existing LEDs D11, D12, D13, D14, D15, D16, D17, D2. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

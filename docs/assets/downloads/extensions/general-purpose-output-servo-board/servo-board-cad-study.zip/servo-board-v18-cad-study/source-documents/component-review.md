# Servo output component selection

Reviewed `docs/ic-opportunities.html`, opportunity `servo-pwm16`, existing v04 BOM and direct seven-host-channel contract. Retain four UCC27524A dual drivers and the explicit output pull-downs. PCA9685 is a distinct I²C PWM-generator variant; it cannot supply the required ≥100 mA signal current alone and would require populated Qwiic, firmware, shared-frequency and startup qualification. Adding it to this direct buffered breakout is not a drop-in improvement.

Neither stocked 74HCT541 nor 74LCX07 establishes ≥100 mA per-channel output capability. Retain the strong drivers. V04 used 0805 bypass capacitors. The connected v10 candidate deliberately changes only C3/C5/C7/C9 (100 nF / 50 V X7R) to GRM188R71H104KA93D 0603, matching the v1 stocked package/value/rating class. C4/C6/C8/C10 remain 1 µF / 25 V 0805; bulk and high-current parts retain their original packages. Actual stocked lot dielectric/tolerance/DC-bias qualification remains required. Signal supply and servo power budgets remain separate qualifications.

## Stock sources and selection boundary

Reviewed both `data/component-reuse/smoothieboard-v1-20261011.csv` (SHA-256 4a740a810ec4da5518ad49e3dc94a5b02bcd728f60fe683365cf5d5a58fc97cc) and `smoothieboard-v2-prime2590-20261011.csv` (SHA-256 4a2472da3c12c9bb7d5e66e6e2ddf7fad7023dbc45e5bb635086a99d0ae1bcd8), via their shared catalog. These are the user-stated stocked-component reference, not measured quantities.

V1 row 10 provides 0.1 µF / 50 V C0603; this matches the value/rating/package class of the deliberately selected GRM188 100 nF / 50 V bypass capacitors. The source does not specify exact manufacturer, dielectric, tolerance or DC-bias curve, so accepting an actual stocked lot requires confirming those markings. V2 row 4 is 100 nF 0402 and cannot populate a 0603/0805 footprint without a new layout. V1 row 59 supplies 10 kΩ / 10% R0603; it cannot silently replace a 1% precision ratio. V2 row 7 is 10 kΩ 0402 and its package differs. V1 row 136 SN74LVC1G04DBVR is an inverter, not a generic interchangeable gate. V2 rows 36/42 are 74HCT541 TSSOP20 / 74LCX07 TSSOP14; their behavior and footprint must match the actual function. No unsourced MPN equality is inferred.

Review date: 2026-10-11. Native ERC/DRC does not qualify the electrical circuit, actual stock lot, supplier body dimensions or physical host.

V10 repairs all seven chain signals and adds a dedicated J2 pin10 ground return to the C10 return. The dense escape uses 0.3 mm copper and 0.6/0.3 mm vias (0.15 mm nominal annulus); native project clearance and annulus rules must pass. One redundant standalone ground stitch was removed before routing, and 41 exact duplicated same-net/width/layer track segments were removed. High-current budgets, actual signal drive, return impedance and thermal behavior remain physically unsigned.

## Current sealed v10 reconciliation — 2026-10-11

Frozenv01–v04/v10 preserved; ceilingv12,no successor. Current v10 already implements four V1-compatible0603 bypasses; do not add a duplicate conversion. Retain four UCC27524A drivers/direct seven-channel interface; PCA9685 requires a separate bus/firmware contract and does not provide the required output drive itself.

Complete [own native BOM](attempt/versions/v10/exports/native-bom.csv) inventory:

| References | Selected value / identity |
| --- | --- |
| C1,C2 | 22uF 25V X7R / GRM32ER71E226KE15L |
| C3,C5,C7,C9 | 100nF 50V X7R / GRM188R71H104KA93D |
| C4,C6,C8,C10 | 1uF 25V X7R / GRM21BR71E105KA99L |
| D1 | SMBJ6.0A (6V-class) / SMBJ6.0A |
| D2 | CONN PWR / APT1608SGC |
| D11 | OUT 1 HIGH / APT1608SYCK |
| D12 | OUT 2 HIGH / APT1608SYCK |
| D13 | OUT 3 HIGH / APT1608SYCK |
| D14 | OUT 4 HIGH / APT1608SYCK |
| D15 | OUT 5 HIGH / APT1608SYCK |
| D16 | OUT 6 HIGH / APT1608SYCK |
| D17 | OUT 7 HIGH / APT1608SYCK |
| F1 | 3A FAST 125V / 0451003.MRL |
| F2 | 0.2A HOLD / MF-NSMF020-2 |
| F3-F9 | 1.1A HOLD / MF-MSMF110/16X-2 |
| FID1-FID6 | FID / printed feature |
| H1-H4 | M3 NPTH 3.2 / printed feature |
| J1 | Y HOST IN / SHF-105-01-L-D-TH-LC |
| J2 | Y CHAIN OUT / SHF-105-01-L-D-TH-LC |
| J3 | SERVO 1 G V S / 22-27-2031 |
| J4 | SERVO 2 G V S / 22-27-2031 |
| J5 | SERVO 3 G V S / 22-27-2031 |
| J6 | SERVO 4 G V S / 22-27-2031 |
| J7 | SERVO 5 G V S / 22-27-2031 |
| J8 | SERVO 6 G V S / 22-27-2031 |
| J9 | SERVO 7 G V S / 22-27-2031 |
| J10 | EXT + / GND / 1984617 |
| JP1 | CONN_PWR: EXT | HOST / FAB-JP-3PAD-12 |
| JP2 | SIG_VDD: HOST | CONN / FAB-JP-3PAD-12 |
| JP11 | CHAIN 1 LINK / FAB-LINK-OPEN |
| JP12 | CHAIN 2 LINK / FAB-LINK-OPEN |
| JP13 | CHAIN 3 LINK / FAB-LINK-OPEN |
| JP14 | CHAIN 4 LINK / FAB-LINK-OPEN |
| JP15 | CHAIN 5 LINK / FAB-LINK-OPEN |
| JP16 | CHAIN 6 LINK / FAB-LINK-OPEN |
| JP17 | CHAIN 7 LINK / FAB-LINK-OPEN |
| JP18 | CHAIN 3V3 LINK / FAB-LINK-BRIDGED |
| JP19 | CHAIN 5V LINK / FAB-LINK-BRIDGED |
| Q1 | P-FET REVERSE POLARITY / DMP4015SSS-13 |
| R1,R31-R37 | 10k / RC0805FR-0710KL |
| R2 | 3.3k / RC0805FR-073K3L |
| R11-R17 | 47k / RC0805FR-0747KL |
| R21-R27 | 10R / RC1206FR-0710RL |
| R41-R47 | 2.2k / RC0805FR-072K2L |
| TP1 | +3V3 / printed feature |
| TP2 | HOST_FUSED / printed feature |
| TP3 | EXT_PROT / printed feature |
| TP4 | CONN_PWR / printed feature |
| TP5 | SIG_VDD / printed feature |
| TP6,TP7 | GND / printed feature |
| U1 | UCC27524A CH1+CH2 / UCC27524ADR |
| U2 | UCC27524A CH3+CH4 / UCC27524ADR |
| U3 | UCC27524A CH5+CH6 / UCC27524ADR |
| U4 | UCC27524A CH7+SPARE / UCC27524ADR |

All101 contract/native records reconcile:73 purchased MPNs match,11 printed solder links,seven testpads,six fiducials and four mounting holes. The shared SMBJ6.0A manufacturer field names two suppliers and is not an exact approved supplier ordering suffix. V1 C11 record10 supports a conditional100nF50V0603 class at C3/C5/C7/C9; actual X7R/tolerance/bias/reel still require confirmation. Other capacitor/resistor packages, precision and current ratings remain selected; generic V2 LEDs/passives or nearby V1 values do not approve replacement of named load-path parts. Keep the fuse/TVS/reverse protection/terminal selection until electrical/thermal/fault/fit gates pass.

Readback matches82 selected sealed members and483 listed artifact-manifest members acrossv01/v10,zero mismatches; no equivalent v02–v04 artifact-manifest coverage asserted. PCB SHA-256 `f7627ae277823be41d1d978d29c0adcd4afe11940d3d9de48dd10d8cbde882ea`. Retained ERC/DRC/opens/parity0,no ignored categories. Retained109-via/193-SMD-pad drill/annular screen0; physical solder process unqualified. STEP export failed; six own views/CAM recorded by native owner,no fresh native run/render here. Checklist8pass/96unsigned/27not-applicable/1fail. Signal drive versus servo-power budgets, source selector/backfeed/startup, 3A fuse protection and surge/PTC compatibility, heat/return impedance, actual connectors/cables and machine fiducials remain unqualified. The contract itself records a TVS clamp above the PTC16V rating under surge; native routing does not resolve that condition. No fabrication or physical acceptance.

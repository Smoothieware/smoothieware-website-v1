---
status: candidate-unqualified
revision: v11
priority: unspecified
gadgeteer_socket_types: [Y]
reserved_by: null
designed_by: "Bob Cousins"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/BreakoutPins"
source_section: "data/extracted/spec.txt:135-145"
---

# Raw pins breakout specifications

## Purpose

Expose one canonical Y-socket's ten contacts on a straight 2.54 mm header with one-to-one mapping and continuous GND. The v11 study adds seven bidirectional transient shunts on GPIO pins3–9.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Connect existing 2.54 mm cables or prototypes to a Smoothie extension port.
- Observe or route every rail and signal while retaining a downstream chained port.

## Functional requirements

- Provide one keyed 2×5 1.27 mm Y input, one straight 1×10 2.54 mm breakout, and one keyed 2×5 chain connector.
- Route each pin one-to-one; add no pull-up, level translation, filtering, or termination.
- v11 permits only the seven documented shunts from GPIO pins3–9 to GND. They add leakage and capacitance; normal signal peaks must remain at or below their 3.3 V working standoff. High-speed use, clamp survival and unpowered-host operation remain unqualified.
- Label every breakout pin by both number and function.

## Inputs

- One canonical type-Y Gadgeteer port.

## Outputs

- One 1×10 2.54 mm header and one electrically parallel Y chain port.

## Electrical requirements

- Rails remain passive pass-throughs; the lowest-rated connector, trace, cable, or upstream source limits current. TVS parts do not establish receiver overvoltage or power-off protection.
- v04 candidate J1/J3: Samtec SHF-105-01-L-D-TH-LC; exact current/voltage ratings and actual mating cable remain UNVERIFIED. The earlier Amphenol/FCI 20021521-00010T1LF proposal is preserved in the baseline and remains unqualified.

## Optional features

- v04 fits nine shipped-bridged cuttable chain links on pins1-9 only; pin10 GND stays continuous. CAD default continuity is verified separately; resistance, physical cutting and rebridge remain UNVERIFIED.

## Constraints and exclusions

- Footnote [a] requires Y marking plus finished licence, version, and logo silkscreen.
- Do not claim arbitrary socket interoperability.

- This repository specifies hardware only: no firmware changes and this isolated v04 candidate includes KiCad native study files; all earlier native revisions and evidence remain retained, with no firmware.

## Open questions

- Confirm source-backed ratings for the selected Samtec SHF connector, exact ordered J2header and full actual mating cable/host assembly.
- Qualify nine chain-only links for default resistance, cut isolation and rebridge; no GND cutting is permitted.
- Confirm that the stocked LESD8D3.3CAT5G lot is LRC Rev.B SOD-882. The V2 BOM's 0402 footprint name is insufficient evidence of package compatibility.

## Current retained study

v05–v10 improve exact J2 drilling, component metadata, GND stitching, rail width, thermal spokes and outline. v10/v11 measure 28.4 × 32 mm and preserve the 20 mm mounting grid. v11 adds D1–D7 on the bottom at J2 with short dedicated returns. Native CAD and review exports are evidence of the design; physical, supplier, host and ESD qualification remain open. See [component-review.md](component-review.md) and [attempt/README.md](attempt/README.md).

## Source amendments and local evidence

- Footnote [a]: Look cute! Needs some silk work (license, version, logos, and call the gadget type Y)
- Tagged source figure: [BreakoutPins.png](../../data/extracted/images/image21.png)

## Prior art and evidence

- Bob Cousins BreakoutPins design and tagged BreakoutPins.png.
- Connector candidate evidence in research.md.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.

## v04 candidate release boundary

The isolated contract at attempt/versions/v04/design-contract.json selects the actual 29x32mm/20 mm hole-lattice passive topology and records traceability/manufacturing requirements. Candidate fabrication notes specify requested lead-free HASL; no supplier approval exists. Exposed off-board GPIO has no fitted ESD protection, so literal S052 remains FAIL. Transparent-pass-through intent is not a protection waiver. All 132 checklist/266 rule items and final v04 exports, renders, independent and physical gates must be reviewed before release.

## Export-bound v04

Actual configured ERC/DRC/opens/parity0 and own CAM/assembly/schematic/six3D outputs exist. Four complete title comments replace clipped predecessor without electrical change. Full132/266 audit still fails protection/source/model/physical gates; no signoff/fabrication. See attempt/versions/v04/verification.json and attempt/qualification.md.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Keep passive one-to-one adapter and exact keyed connectors; retain seven conditional V2 LRC SOD-882 shunts already in v11; no further revision. Current selected v11; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v11**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: preserve incompatible/non-3/4-pin interfaces listed in local record; audit fuse references none extracted and power-entry candidates none extracted; independently disable existing LEDs none extracted. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

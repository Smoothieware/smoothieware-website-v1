---
status: prototype-contract-unverified
priority: unspecified
gadgeteer_socket_types: []
reserved_by: null
designed_by: "Ray Kholodovsky and Bob Cousins"
reference_url: "https://github.com/Smoothieware/Smoothieboard2/tree/master/extensions/Small%20MOSFET_kicad"
source_section: "data/extracted/spec.txt:208-226"
---

# Single-Channel Small MOSFET output specifications

## Purpose

Switch one 5–24 V DC load using a low-side MOSFET and flyback protection. The external-supply design target is 5 A; it is not a qualified rating. Host-supplied operation is a separate, default-disabled prototype mode, limited to 0.5 A only after an upstream allocation is authorized.

This hardware specification is released under CERN OHL and all design work must be performed in KiCad only.

## Use cases

- Control a fan, solenoid, hotend heater, or other qualified DC load.

## Functional requirements

- Accept Ground/5–12 V/Signal from the servo-output board and optional 5–24 V terminal power.
- Use low-side switching with a reset-safe gate pull-down.
- Provide a flyback path for supported inductive loads.
- Select the usable source without an intentional DC backfeed path upstream. Verify finite leakage and switching transients physically. Use a removable, default-open host-load link; when it is closed, either source may supply the whole load and total load current must remain within the authorized host allocation.

## Inputs

- One white polarized/latching Molex KK-254 three-pin connector: pin 1 Ground, pin 2 host 5–12 V, pin 3 Signal. The selected 22-27-2031 header is polarized to its intended mate, but the manufacturer lists no separate keying feature. Harness fit and reverse-insertion rejection remain release gates; generic unkeyed plugs are not acceptable substitutes.
- One 3.5 mm 5–24 V DC power terminal.

## Outputs

- One 3.5 mm two-pole load terminal.

## Electrical requirements

- At least 5 A is the external-source target, subject to connector/copper/thermal validation; do not print a 5 A or historical 7 A qualified maximum.
- Signal must be a buffered 5 V level: HIGH 4.75–5.25 V, LOW at most 0.4 V, driver capable of at least 100 mA transient source/sink. A native 3.3 V GPIO is not within this prototype contract.
- Initial PWM qualification starts at no more than 1 kHz. No higher frequency is qualified by this document.
- Both supplies need common ground and overload/short protection. The external input permits static reverse connection down to −24 V in the proposed topology; this is not a standardized surge or automotive qualification.
- The host-load link is open by default. Its 0.75 A fuse is fault protection, not a precise 0.5 A current limiter or an upstream budget approval.
- MOSFET VDS needs margin above 24 V plus transients; the historical ZXMN4A06 is prior art, not an automatic selection.

## Optional features

- Buffered status LED is fitted in the prototype. It indicates gate command with load power present, not verified load current or heater safety.

## Constraints and exclusions

- Footnotes [f]/[g] require schematic review, complete silk, and a connector-facing decision.
- DC low-side loads only; no mains or arbitrary bidirectional load.

- This authorized local attempt produces retained KiCad prototype files under `attempt/`. It does not change firmware or certify physical safety/fabrication readiness. Every retained revision and failed check remains evidence.

## Open questions

- Qualify the selected MOSFET, diode, fuse, TVS, copper and terminal assembly under the actual load, ambient, enclosure, wiring and supply limits.
- Terminals face west/east for this prototype, permitted by [g]. Confirm cable and screwdriver clearance physically; south-facing alternatives remain possible if fit evidence requires a later revision.
- Obtain an upstream-power allocation before closing the host-load link. The proposed 0.5 A mode is not an allocation inferred from the shared regulator.
- Confirm exact order-code availability, Molex mate/harness, footprint/body origins and assembly paste/drill requirements before fabrication.
- Measure source-state/backfeed/reverse behavior, reset and PWM waveforms, 5 A thermal soak and the selected inductive load's turn-off transient. Arbitrary solenoid energy or PWM diode duty is not supported merely by a 5 A diode label.

## Source amendments and local evidence

- Footnote [f]: Need to review schematic, silk needs license, version, and logos, would this be better if the screw terminals faced S?
- Footnote [g]: Fine either way right now.
- Tagged source figure: [Small MOSFET.png](../../data/extracted/images/image14.png)

## Prior art and evidence

- Historical Small MOSFET KiCad design and tagged Small MOSFET.png.
- Smoothieware low-side MOSFET documentation cited in research.md.

The source excerpt, amendments, local images, and current-platform evidence are preserved in [research.md](research.md). Prior art is evidence, not proof that its schematic or footprint matches current Smoothie V2 hardware.


## 2026-10-11 scoped revision and component reuse review

Keep the two LM74700 ideal-diode branches and the selected 60/100 V power MOSFETs. The IC guide provides no equivalent single-channel low-side power-stage simplification that preserves the reverse/backfeed and two-source contract. Do not replace these with a relay or motor driver. Q4 2N7002 in SOT-23 matches v2 Q26 at the device-family and package level. Preserve the selected Nexperia 2N7002,215 unless stock order code/pinout is confirmed. V2 10 kΩ and 100 nF are predominantly 0402; they are not footprint matches to this board's 0805 passives. No exact stocked high-current fuse, ideal-diode controller or SON power-FET match was established.

The owned revision work completes every retained package from its own saved native CAD and brings each motor-driver family to v10. Earlier studies and their defects remain retained. Mandatory 132-item schematic/layout evidence, strict DRC with schematic parity, fresh fill/readback, complete fabrication/assembly exports and all six black board views are required per version. Unverified host, supplier, physical and thermal gates remain unsigned; exports are not permission to fabricate.

### Group 5 ordinary-via assembly correction (v22)

The current engineering candidate is v22. It preserves the electrical parts, interfaces, ratings and outline while moving ordinary vias clear of exact SMT drill/annulus/mask contacts. v21 remains an immutable historical package with an assembly-rejection supplement. Exact source-bound native gates and the six-view package are in `attempt/versions/v22/group5-package/`. Existing documented thermal VIPPO requirements, when present, still need supplier approval. Physical/load/host/thermal qualification and all unsigned literal132/260 actionable rule gates remain open.


## Current IC/stock disposition — 2026-10-11

See [current review](component-review.md). Retain dual LM74700 ideal-diode branches and60/100VpowerFETs. Existing Q4 V2generic2N7002/SOT23 and V1 Molex connector family retained;0805supports not0402stock dropins,no successor. Current selected v22; retained native/stock/physical qualification limits remain explicit.

## Mandatory family upgrade contract — 2026-10-11

The [family upgrade specification](../../docs/FANCIFICATION-SPEC.md) and [design rules](../../docs/DESIGN-RULES.md) are mandatory. Use this board’s [F01–F10 work record](fancification.md) and [native baseline/pin-map contract](fancification-contract.json); they separate current hardware from required work and exclusions.

Frozen pre-program maximum **v22**; at most **three additional meaningful native revisions** for this program, superseding older pass ceilings for this program only. Apply multiple applicable upgrades first, then measured fixes/improvements. Preserve history. Text is not CAD implementation or qualification.

Priorities: compact PH/SH alternatives at J1; audit fuse references F1, F2 and power-entry candidates J1, J2; independently disable existing LEDs D6. Preserve pin order and route alternatives by named nets: three-wire STEMMA is PH 2 mm; 3.3 V I2C QT is SH 1 mm. Custom/hazardous interfaces must not be mislabeled QT.

Require applicable connector-population renders/BOM/paste, per-LED links, uppercase Montserrat/both-face labels, authored website source, 10 mm mounting datum/grid, useful strain relief and no-cost test access. No fault memory, identify blink, identity EEPROM or added calibration/self-test/recovery hardware. Full CAD/render/checklist/physical qualification are separate gates; the board record names inherited defects and remaining checks.

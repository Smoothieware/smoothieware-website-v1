# Raspberry Pi 40-pin to Gadgeteer HAT design

Derived from [specs.md](specs.md); on conflict the spec is updated first.

## Architecture

```
host header --> [ferrite 3V3] --> protected_3v3 --> sockets pin1, Qwiic pin2
host 5V ------> [back-feed block] --> socket_5v --> sockets pin2
host GPIO ---> [100R] --> [TVS] --> socket contact (per assignment table in specs.md)
GND common; jumpers: JP_LED3V3, JP_LED5V (no I2C pull-ups are fitted; the Pi has 1.8 kohm on GPIO2/3)
```

## Decisions

- Layers: 2 (all signals are slow GPIO/I2C/SPI up to ~20 MHz; no controlled impedance; SPI routed with continuous ground return). Reason: cost rule.
- Connectors: Samtec SHF-105-01-L-D-TH 2x5 1.27 mm shrouded, as on the Arduino shield, plus Qwiic JST SH SM04B-SRSS-TB; host mating headers are 2.54 mm female receptacles. Connectors on edges; Gadgeteer sockets face outward.
- Back-feed block: Texas Instruments LM66100DCKR ideal diode (SC-70-6, 1.5 V to 5.5 V, 1.5 A) in the 5 V path so a Smoothieboard-supplied 5 V on a cable cannot back-power the host; CE is tied to VOUT so the device disables when the output exceeds the input and enables forward conduction when the input exceeds the output, subject to the datasheet comparator thresholds; N/C (pin 4) and ST (pin 5) are unconnected; input and output each have a 10 uF bypass capacitor within 5 mm. The ferrite bead FB1 stays on the 3.3 V path. This is the reverse-current-blocking connection described in [TI LM66100 Rev. A, pin functions and feature description](https://www.ti.com/lit/ds/symlink/lm66100.pdf), not unconditional enable. Bench validation remains open. Datasheet review is recorded in the contract `sources` (flag verified or unverified per document).
- TVS: single-channel Texas Instruments TPD1E10B06DPYR (bidirectional, 0402-size X2SON) on every GPIO (D1 to D26) and on the Qwiic SDA/SCL (D27, D28). Underside placement (DESIGN-RULES line 205 conditional): the TVS parts sit on the bottom side immediately behind the header receptacle pad column, which keeps the ESD path short, keeps the ground return local, and keeps the top side free for the five sockets; the return goes to the bottom GND pour, no vias between the header pad and the TVS signal pad.
- I2C: no pull-ups fitted (the Pi provides 1.8 kohm to 3.3 V on GPIO2/3); Qwiic bus shares the I2C socket SDA/SCL; Qwiic is 3.3 V only.
- Mounting: the four M2.5 interface holes mandated by the Raspberry Pi HAT standard ((3.5,3.5), (61.5,3.5), (3.5,52.5), (61.5,52.5) mm, 58 x 49 mm spacing) are a recorded exception to the M3 10 mm grid rule; they are non-plated, carry no net and keep a copper-free 6.2 mm land. No extra M3 holes are added: the board is only 65 x 56 mm, the sockets, header receptacle and PoE keepout fill the area, and the four HAT holes already fix the board to the Pi. Two 2.5 mm cable-tie holes (H5, H6) are provided where space remains (F09). Coordinates are audited by script.
- Layout-driven socket assignment: see the table in specs.md (header pad -> 100 ohm -> TVS -> socket contact).
- Fiducials: three on each face (FID1 to FID3 top, FID4 to FID6 bottom) in a non-symmetric pattern.
- Montserrat title font: the installed Montserrat is a variable font that fontconfig resolves to the Thin master; KiCad DRC therefore reports 2 text_thickness warnings on the large title text. The warnings are accepted and recorded; the font file is ~/.local/share/fonts/Montserrat-VariableFont_wght.ttf.
- Test pads TP1 to TP6 (top face, silk net labels from v02): TP1 H3V3 and TP2 H5V on the Pi side of the supply path, TP3 P3V3 and TP4 P5V on the socket side, TP5 and TP6 GND. No test pads on signal lines: the 0402 series-resistor pads and socket pins give access, and a stub on a GPIO would bypass the protection layout (F10). Expected readings (design intent, unmeasured): TP1 = Pi 3.3 V, TP3 = TP1 minus the ferrite drop, TP2 = Pi 5 V, TP4 = TP2 minus the LM66100 drop.
- Silkscreen: board name, version, socket letters, pin-1 markers, host pin legends, license, URL; unused-contact NC notes.
- Daisy-chain: not provided (each socket is a host-direct port); documented exclusion.

## Gadgeteer pin map

See the assignment table in [specs.md](specs.md); the machine-usable net table is generated into `attempt/design-contract.json` by the CAD agent.

## Power budget

See specs.md. Worst case: all sockets at limit; verify ferrite DC drop and back-feed block voltage drop at 500 mA 5 V.

## Verification owed

Per version the packager produces ERC/DRC/parity reports, the 132-item checklist review, populated and bare renders for both connector populations, Gerbers and drill. Physical qualification, supplier checks and several datasheet items stay unverified; see qualification.md.

## Rule inheritance (all mandatory; not re-derived here)

- Interface standard and socket types: `CLAUDE.md` section 3 (Version 16 table). Design rules: `docs/DESIGN-RULES.md`; family upgrade: `docs/FANCIFICATION-SPEC.md` (F01-F10); trusted power: `docs/trusted-power-compact-layout-spec.md`; checklists: `docs/pcb-checklist/` (132 items); process: `docs/board-design-process.md`.
- Host rails over the board are trusted (no generic reverse-polarity/OV/eFuse block); functional back-feed blocking, per-LED solder-jumper disables and test pads are kept.
- Powered-peer restriction: do not inject 3.3 V through Gadgeteer pin 1 or either I2C connector supply contact, including while the Pi is off. FB1 filters noise but provides no DC isolation, reverse-current blocking or enforced current limit; U1 protects only the 5 V path. This rail connection must obey the [Raspberry Pi HAT guide prohibition on supplying the GPIO header 3.3 V pins](https://github.com/raspberrypi/hats/blob/master/designguide.md#back-powering-the-pi-via-the-gpio-header). Supply budgets and reverse-current behavior remain unverified on hardware.
- Black mask, white silk, 2 layers unless proven necessary, connectors on edges, M3 ungrounded holes on the 10 mm grid except fixed interface holes (listed separately), CERN OHL, KiCad only.
- Mandatory populated Qwiic (JST SH 1.0 mm, 3.3 V only) on the I2C bus, plus the 2.54 mm alternative population (F01/F02).
- Every Gadgeteer socket must be a 1.27 mm 2x5 keyed connector with unused contacts individually NC. Silkscreen prints `smoothieware.org/extensions/<slug>` and the website page source must exist (F08).

## Evidence record (Step 1, verified 2026-10-22)

Checked by the CAD agent from primary sources; PDFs were read as downloaded text/figures.

- Raspberry Pi HAT mechanical drawing: https://github.com/raspberrypi/hats/blob/master/hat-board-mechanical.pdf - board 65 x 56.5 mm (SMT header) or 56.0 mm (through-hole header), R = 3 mm corners; four holes at (3.5,3.5), (61.5,3.5), (3.5,52.5), (61.5,52.5), 58 x 49 mm spacing, 2.75 mm drill for M2.5, land at least 6.2 mm, non-plated and not GND; 2x20 header centred at x = 32.5 mm, pin 1 pad at x = 8.37, pin 40 at x = 56.63, odd pins y = 4.77, even pins y = 2.23, pitch 2.54; PoE 4-pin header keepout near (61.5, 9.64).
- Raspberry Pi HATs specification and design guide: https://github.com/raspberrypi/hats (README.md, designguide.md) - ID_SC/ID_SD (GPIO0/1, pins 27/28) are for an ID EEPROM only, otherwise leave unconnected; a back-powering board needs an ideal diode or equivalent; protect against old firmware driving GPIO6, GPIO14, GPIO16 at boot (series resistors serve); no power source on the 3.3 V header pins.
- Raspberry Pi 4 Model B datasheet, Figure 3 (J8 pinout): https://datasheets.raspberrypi.com/rpi4/raspberry-pi-4-datasheet.pdf - 3V3 pins 1,17; 5V pins 2,4; GND pins 6,9,14,20,25,30,34,39; GPIO2=3, GPIO3=5, GPIO4=7, GPIO14=8, GPIO15=10, GPIO17=11, GPIO18=12, GPIO27=13, GPIO22=15, GPIO23=16, GPIO24=18, GPIO10=19, GPIO9=21, GPIO25=22, GPIO11=23, GPIO8=24, GPIO7=26, ID_SD=27, ID_SC=28, GPIO5=29, GPIO6=31, GPIO12=32, GPIO13=33, GPIO19=35, GPIO16=36, GPIO26=37, GPIO20=38, GPIO21=40. I2C1 = GPIO2/3, UART0 = GPIO14/15, SPI0 CE0 = GPIO8, MISO GPIO9, MOSI GPIO10, SCLK GPIO11, CE1 = GPIO7, PWM0/1 on GPIO12/13 (GPIO18/19 ALT5). VIN absolute maximum 6.0 V.
- No official header current limit is published: 40 mA and 500 mA remain labelled design assumptions.
- Result: the draft's "28 non-reserved GPIO" was wrong (26 usable); the draft's outline height was loosely 56 mm and is now the through-hole 56.0 mm; the JP_PU pull-up jumper in the architecture sketch contradicted the no-pull-ups decision and was removed.
- Part datasheets (LM66100 ideal diode, JST SH SM04B-SRSS-TB, TPD1E10B06 TVS) are recorded in `attempt/design-contract.json` `sources` with a verified or unverified flag.

## Header geometry (generator asserts)

Receptacle on the bottom side; seen from the top, pad 1 at (8.37, 4.77), pad 2 at (8.37, 2.23), pad 40 at (56.63, 2.23). Column index c = (N+1)//2 - 1, x = 8.37 + 2.54 c; odd pins on the inner row (y = 4.77), even pins on the outer row (y = 2.23).

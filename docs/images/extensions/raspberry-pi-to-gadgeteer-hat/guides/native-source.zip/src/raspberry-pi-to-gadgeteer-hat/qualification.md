# raspberry-pi-to-gadgeteer-hat - qualification status

Date 2026-10-22. Latest version: **v03**. Overall status: **`cad-clean-unqualified` for v02 and v03; v01 is `not-cad-clean`. Not signed off, not independently reviewed, not fabrication-ready, not physically qualified.** The checklist signoff is not granted in any version: one item fails (S051) and 37 are unverified. Reviewer: Claude Sonnet 5.5 (workflow senior executor), single-author self-review, not independent.

## What was and was not achieved

- Done for every version (v01, v02, v03): native KiCad 9.0.8 schematic and PCB generated from one part table, ERC, DRC with schematic parity (kicad-cli), proof that the custom rules work (a deliberate violation triggers both the 0.4 mm power-track rule and the HAT keep-out rule area), BOM and placement CSV per connector population (Qwiic J6 default, 2.54 mm header J7 alternative), Gerber and drill export, gerbv CAM preview, assembly and copper drawings, schematic PDF and netlist, 12 black-mask renders (populated and bare, top, bottom, isometric, both populations; 3D models verified visible), render provenance, command log, SHA-256 manifest, and a 132-item checklist review (every item has exactly one disposition).
- Routing and the ni-build rule: all copper is explicit (segments written directly by the generator, GND pours refilled by KiCad) and the saved boards have 0 unconnected items. No automatic router was run. The ni-build README (PCB section) says: "Use `ni-build pcb` for KiCad/pcbnew scripts, KiCad CLI jobs and FreeRouting, never a local router fallback." Two consequences, both recorded as deviations or gaps rather than hidden. (1) No independent route or verification pass through `ni-build pcb` was attempted: the shared ni-vm PCB queue was occupied by other owners' jobs (the same wording is in each version's `reports/gates.json`, `routing_blocker`) and a local router fallback is prohibited, so the copper has never been checked by an independent router or by the ni-build PCB service; it is the result of a script plus KiCad DRC only. (2) The per-version ERC, DRC, exports and renders were run locally with kicad-cli and pcbnew, although the quoted sentence also names KiCad/pcbnew scripts and KiCad CLI jobs. This is a deviation from that README sentence; the reason is that these are light per-version checks and the PCB queue was blocked. No routing job was submitted to ni-vm; the only ni-vm submissions were queue probes (including ni-build job `6ff4bf5230f64ad0989df765ccf429e1`) whose results are not used for any statement in this package. After the packages were finished, the last queue probe (a tiny remote pcbnew plus kicad-cli render test) was admitted on ni-vm and succeeded (KiCad 9.0.8, render exit code 0), so the remote PCB route works now; no per-version check was re-run through it, so the deviation above still stands.
- Not done: any physical build, any measurement, any independent review, any manufacturer capability check.

## Per-version results

| Version | Status | ERC | DRC | Unconnected | Parity | Checklist pass / fail / unverified / n-a | Signoff |
| --- | --- | ---: | --- | ---: | ---: | --- | --- |
| v01 | not-cad-clean | 0 | 11 errors (`track_width`) + 2 warnings (`text_thickness`) | 0 | 0 | 28 / 6 / 36 / 62 | no |
| v02 | cad-clean-unqualified | 0 | 0 errors + 2 warnings (`text_thickness`) | 0 | 0 | 32 / 1 / 37 / 62 | no |
| v03 | cad-clean-unqualified | 0 | 0 errors + 2 warnings (`text_thickness`) | 0 | 0 | 32 / 1 / 37 / 62 | no |

Counts come from `attempt/versions/vNN/reports/gates.json` and `checklist-review/checklist-132.json`; they are also in `attempt/versions.json` and the design contract `attempt/design-contract.json`. Each version's `manifest.json` lists the SHA-256 of every file in it. `cad-clean-unqualified` means ERC 0, DRC 0 errors, 0 unconnected, parity 0 on that version's saved board and nothing more.

## Version history

- v01: generator baseline. Its DRC reports 11 power-net tracks at 0.2 mm below the 0.4 mm power rule, two title-text warnings, and the checklist fails L012 (layer markers), L064 (date), L065 (serial box), L067 (test pad labels) as well as L002 and S051.
- v02 (base v01): power tracks widened to 0.5 mm (3 at the 0.4 mm fallback), U1 feeder moved 0.3 mm, layer markers, date, serial-number box and test-pad net labels added. Checklist fails drop from 6 to 1.
- v03 (base v02): a GND return via beside each of the 28 TVS diodes. Counts equal v02 because the checklist items touched are unverified either way; the change is a shorter ESD return path, unmeasured.
- Discarded intermediate attempts (three for v02, one for v03) were moved to scratch and are not retained versions.

## Checklist: failing items (v03)

| Item | Why it fails | Next action |
| --- | --- | --- |
| S051 | No current limit on the 3.3 V and 5 V rails forwarded to five sockets. Accepted by the trusted-power policy but a real gap. | Owner decision; add a fuse or limiter if the policy changes. |

v01 additionally fails L002, L012, L064, L065 and L067 (all fixed in v02, L002 apart from the two accepted text warnings: it is reported as unverified in v02 and v03 because of them).

## Checklist: unverified items (37 in v02 and v03)

Schematic: S002, S003, S006, S007, S008, S012, S014, S020, S023, S025, S034, S046, S057 (pin numbers and ratings needing datasheet reads, capacitor derating, rail budgets, LM66100 enable polarity and decoupling, GPIO boot states, signal test points). Layout: L001 (schematic signoff), L002 (two `text_thickness` warnings remain), L004, L005, L006, L009, L017, L018, L019, L020, L022, L023, L034, L035, L039, L041, L044, L049, L050, L054, L057, L061, L063, L072 (manufacturer capability and stackup, package availability, connector and ferrite current ratings, 1:1 print, hand-written 3D models, plane slots, current capacity of the downstream rails, PoE keep-out, mating clearance, 3D collisions, probe access, stencil and silk review, CAM inspection). The per-item reasons and next actions are in `attempt/versions/v03/checklist-review/checklist-132.json`.

## Engineering risks that are not CAD defects

- Pi GPIO are 3.3 V only and not 5 V tolerant; the board does no level shifting. A 5 V signal on a socket contact can damage the Pi. The 100 ohm series resistor and TPD1E10B06 diode only help against ESD.
- Boot: GPIO6, GPIO14 and GPIO16 may be driven briefly by older firmware at boot (J2.4, J2.5, J3.4).
- The 40 mA (3.3 V) and 500 mA (5 V) budgets, the ferrite and ideal-diode drops under load, and the Pi header pin current capability are design assumptions, not measured or manufacturer-verified limits. The Pi 4 VIN absolute maximum of 6.0 V bounds the trusted 5 V input.
- GPIO13 and GPIO19 are both PWM1 outputs and produce the same waveform.
- 3D models of the Samtec socket and the TVS are hand-written dimensional approximations. Mechanical fit on a real Pi (with and without a PoE HAT), the HAT outline and keep-out are from the Raspberry Pi HAT mechanical drawing, but a physical fit test was not done.
- The title text warns in DRC (font weight); legibility was judged from renders only.
- All costs, stock and MPN availability are unverified; passives and the ferrite bead are generic.

## Not done and needed before any fabrication claim

Independent review of the layout and schematic; resolve or document every unverified checklist item and the S051 policy; GUI pass for the title text thickness; routing check or re-route through `ni-build pcb` when its PCB queue allows, with the DRC rerun; manufacturer capability and stackup check; physical sample, continuity and rail measurement, a fit test on a Pi with the sockets and a Qwiic cable, and a boot test with sockets loaded. Until then v01, v02 and v03 are labelled unsuitable for fabrication.

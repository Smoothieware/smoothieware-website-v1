---
status: cad-clean-unqualified-candidate
priority: user-requested
gadgeteer_socket_types: [Y, S, U, I, P]
reserved_by: null
designed_by: null
reference_url: null
source_section: "Maintainer /goal request 2026-10-20: host-board adapters for the most popular maker platforms (README entry 82)"
---

# Raspberry Pi 40-pin to Gadgeteer HAT specifications

## Purpose

Let owners of the host below use any Smoothie Gadgeteer extension board with it, with no firmware or second MCU on the adapter: pure wiring, protection and power conditioning.

- Host: Raspberry Pi 2x20 (40-pin) GPIO header: Pi 1 B+/2/3/4/5, Zero/Zero 2 W (headers fitted), 400.
- Logic family: 3.3 V GPIO, no 5 V tolerance on any Pi pin.
- Prior art: Separate from src/raspberry-pi-zero-breakout (older Pi Zero UART breakout with 2x20 header, socket U, reserved by Mikkel Jeppesen, blocked); this board is a general multi-socket host adapter and does not replace it.

## Fixed socket assignments

| Socket | Gadgeteer contacts and host functions |
| --- | --- |
| J1 Y | 3=GPIO5; 4=GPIO27; 5=GPIO7; 6=GPIO22; 7=GPIO25; 8=GPIO23; 9=GPIO24 |
| J2 S | 3=GPIO26; 4=GPIO6; 5=GPIO16; 6=CS GPIO8 (CE0); 7=MOSI GPIO10; 8=MISO GPIO9; 9=SCK GPIO11 |
| J3 U | 3=GPIO18; 4=TX GPIO14; 5=RX GPIO15; 6,7,8,9=NC |
| J4 I | 3=GPIO17; 6=GPIO4; 8=SDA GPIO2; 9=SCL GPIO3; 4,5,7=NC |
| J5 P | 3=GPIO21; 6=GPIO20; 7=PWM GPIO12; 8=PWM GPIO13; 9=PWM GPIO19; 4,5=NC |
| J6 Qwiic | 1=GND; 2=filtered 3.3 V; 3=SDA GPIO2; 4=SCL GPIO3; both MP anchors to GND; no 5 V |

Every socket: pin 1 = filtered host 3.3 V, pin 2 = host 5 V (through the backfeed block below), pin 10 = GND; reserved contacts individually unconnected. Mechanical interface (verified against the Raspberry Pi HAT mechanical drawing, evidence in design.md): outline 65 x 56.0 mm (through-hole header variant; 56.5 mm is the SMT-header variant) with 3 mm corner radius; 2x20 2.54 mm female stacking receptacle on the underside, centred at x = 32.5 mm, pin 1 at (8.37, 4.77) and pin 2 at (8.37, 2.23) seen from the top; the four HAT mounting holes at (3.5,3.5), (61.5,3.5), (3.5,52.5), (61.5,52.5) mm from the board corner (58 x 49 mm spacing) are INTERFACE holes: 2.75 mm non-plated drill for M2.5, at least 6.2 mm land, not connected to GND. They are identified separately from the extra M3 10 mm-grid holes, which are added where clearance permits and justified in design.md if none fit. The Pi PoE 4-pin header keepout near (61.5, 9.64) is respected by placing only top-side parts around it. This is an add-on board, not a certified HAT (no ID EEPROM, no 8 mm standoff requirement is claimed).

## Electrical contract

- Pi 5 V pins (header 2,4) feed socket pin 2 (trusted host rail, no input protection). 3.3 V from header pins 1,17 feed socket pin 1 through a ferrite bead; the Pi 3.3 V header budget is conservatively 50 mA total, so the exported 3.3 V budget is 40 mA across J1-J6 and the 5 V budget is 500 mA total unless the Pi supply is shown to allow more. Host-side GPIO are never driven by a 5 V net.
- Each signal: 100 ohm series resistor (0402) and one single-channel bidirectional TVS diode, Texas Instruments TPD1E10B06DPYR (D1 to D26, one per GPIO, placed on the bottom side directly behind the header pad; D27 and D28 protect the Qwiic SDA and SCL); no level translation; Gadgeteer signals above 3.3 V are out of contract. The alternative 2.54 mm I2C header J7 has no TVS of its own: it shares the SDA/SCL nets of J4 and the protection of the J4 channel (recorded as a remaining item in fancification.md).
- 5 V path: Texas Instruments LM66100DCKR ideal diode (SC-70-6) between the header 5 V and the socket 5 V rail; its CE input is tied to VOUT so the device disables when the output exceeds the input and enables forward conduction when the input exceeds the output, subject to the datasheet comparator thresholds. The N/C and ST pins stay unconnected. The 3.3 V path keeps the ferrite bead FB1. This is the reverse-current-blocking connection described in [TI LM66100 Rev. A, pin functions and feature description](https://www.ti.com/lit/ds/symlink/lm66100.pdf), not unconditional enable. Bench validation remains open.
- Per-LED solder-jumper disable for every fitted LED (3.3 V and 5 V presence, green).

## Host-specific notes and assumptions

- GPIO0/GPIO1 (HAT ID EEPROM bus) are left unconnected; no ID EEPROM is fitted (documented option, no BOM cost added).
- The Pi fits 1.8 kohm I2C pull-ups to 3.3 V on GPIO2/3: the board fits NO pull-ups and J4 and J6 share that one bus.
- The Pi has no ADC: no A socket. TX/RX are named from the host perspective. Pi 5 UART on the header is /dev/ttyAMA0; enable via config.txt, a software item.
- All 26 usable GPIO (GPIO2 to GPIO27) are used exactly once; GPIO0/GPIO1 are the reserved ID pins. No signal sharing except J6 branching J4 SDA/SCL. Within the generic-GPIO sockets (J1, and the generic contacts of J2, J4, J5) any exchange of two interchangeable generic GPIO made only for routing is recorded in design.md and in the contract (`signal_channels`); fixed-function pins (SPI, UART, I2C, PWM) never move.
- Layout-driven assignment (v01 onward): the GPIO-to-contact table above was fixed by the PCB layout, so that header pad, series resistor, TVS and socket contact lie on short non-crossing paths on a 2-layer board. Only interchangeable generic GPIO moved; fixed-function pins (SPI, UART, I2C, PWM) stay on their Pi functions. GPIO19 shares the PWM1 channel with GPIO13 (J5 contacts 8 and 9 produce the same waveform).
- Old Raspberry Pi firmware can drive GPIO6, GPIO14 and GPIO16 at boot (HAT design guide). J2 contacts 4 and 5 (GPIO6, GPIO16) and J3 contact 4 (GPIO14) are therefore behind the 100 ohm series resistors and must not connect to anything that misbehaves when driven briefly; document this on the website page.
- The Raspberry Pi publishes no official current limit for the header 3.3 V and 5 V pins; the 40 mA (3.3 V) and 500 mA (5 V) budgets are DESIGN ASSUMPTIONS, not datasheet values. The Pi 4 VIN absolute maximum is 6.0 V.
- HAT guide rules kept: a board that back-powers the Pi must not (our back-feed block); no power source is attached to the 3.3 V header pins.

## Open questions

- Hardware has not been built or tested; every electrical statement is design intent only.
- Pinouts were verified against the Raspberry Pi Pi 4 datasheet (J8 figure) and the Raspberry Pi HAT specification; evidence and URLs are recorded in design.md. Pi 5 and Zero pinouts are the same 40-pin J8 function map per the same HAT specification.
- The maintainer may prefer a different mix of sockets for this host; the set above was chosen autonomously to use every safe host pin once.

## Rule inheritance (all mandatory; not re-derived here)

- Interface standard and socket types: `CLAUDE.md` section 3 (Version 16 table). Design rules: `docs/DESIGN-RULES.md`; family upgrade: `docs/FANCIFICATION-SPEC.md` (F01-F10); trusted power: `docs/trusted-power-compact-layout-spec.md`; checklists: `docs/pcb-checklist/` (132 items); process: `docs/board-design-process.md`.
- Host rails over the board are trusted (no generic reverse-polarity/OV/eFuse block); functional back-feed blocking, per-LED solder-jumper disables and test pads are kept.
- Powered-peer restriction: do not inject 3.3 V through Gadgeteer pin 1 or either I2C connector supply contact, including while the Pi is off. FB1 filters noise but provides no DC isolation, reverse-current blocking or enforced current limit; U1 protects only the 5 V path. This rail connection must obey the [Raspberry Pi HAT guide prohibition on supplying the GPIO header 3.3 V pins](https://github.com/raspberrypi/hats/blob/master/designguide.md#back-powering-the-pi-via-the-gpio-header). Supply budgets and reverse-current behavior remain unverified on hardware.
- Black mask, white silk, 2 layers unless proven necessary, connectors on edges, M3 ungrounded holes on the 10 mm grid except fixed interface holes (listed separately), CERN OHL, KiCad only.
- Mandatory populated Qwiic (JST SH 1.0 mm, 3.3 V only) on the I2C bus, plus the 2.54 mm alternative population (F01/F02).
- Every Gadgeteer socket must be a 1.27 mm 2x5 keyed connector with unused contacts individually NC. Silkscreen prints `smoothieware.org/extensions/<slug>` and the website page source must exist (F08).

"""Reflow frozen source-bound annotations, preserving source artwork and original receipts."""
from pathlib import Path
import copy, hashlib, html, json, re, textwrap, xml.etree.ElementTree as E
R=Path(__file__).resolve().parent
OLD=R/'editable-inputs'
OUT=R/'reproduced'
NS='http://www.w3.org/2000/svg'
E.register_namespace('',NS)
SLUGS=['a5984-stepper-driver', 'chip-dip-computer-carrier', 'large-mosfet-eagle']
def txt(x,y,s,size=24):
 e=E.Element('{'+NS+'}text',x=str(x),y=str(y),fill='#e4e8ed',**{'font-family':'Arial,sans-serif','font-size':str(size)});e.text=s;return e
def canvas(title,sub):
 root=E.Element('{'+NS+'}svg',viewBox='0 0 2500 1400');E.SubElement(root,'{'+NS+'}rect',width='2500',height='1400',fill='#202328');root.extend([txt(35,55,title,34),txt(35,100,sub,23)]);return root
def save(root,p):
 p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(root).write(p,encoding='unicode');return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def tag(e):return e.tag.rsplit('}',1)[-1]
def extract_groups(root):
 groups=[];cur=None
 for e in root:
  if tag(e)=='text' and float(e.get('y','0'))>120 and float(e.get('x','0')) in [20,30,35,1215,1230,1710,2060]:
   # A connector heading is followed by segmented pill groups, unlike footer notes.
   cur={'heading':e.text or '', 'contacts':[], 'locators':[]};groups.append(cur)
  elif cur and tag(e)=='g' and (e.get('data-contact') is not None or e.get('data-reference') is not None):
   ts=[v.text or '' for v in e.iter() if tag(v)=='text']
   if len(ts)>=2:cur['contacts'].append((ts[-1],ts[-2]))
  elif cur and tag(e)=='path' and 'L' in e.get('d',''):
   nums=re.findall(r'-?\d+(?:\.\d+)?',e.get('d',''))
   if len(nums)>=4:cur['locators'].append(tuple(map(float,nums[:2])))
 return [g for g in groups if g['contacts']]
def pill(root,x,y,k,s):
 # Two lines preserve complete role strings without shrinking them into unreadable text.
 key_width=max(100,min(280,len(k)*13+25));role_width=745-key_width
 lines=textwrap.wrap(s,max(25,int((role_width-20)/11.5))) or [''];h=max(35,len(lines)*27+10)
 E.SubElement(root,'{'+NS+'}rect',x=str(x),y=str(y-25),width='745',height=str(h),rx='12',fill='#087361')
 E.SubElement(root,'{'+NS+'}rect',x=str(x+role_width),y=str(y-25),width=str(key_width),height=str(h),rx='12',fill='#11191f')
 for i,line in enumerate(lines):root.append(txt(x+10,y+i*27,line,22))
 root.append(txt(x+role_width+10,y,k,22));return h+7
if __name__ == '__main__':
 source=json.loads((OLD/'integration-map.json').read_text());records=[]
 for record in source['records']:
  slug=record['slug']
  if slug not in SLUGS:continue
  files=[];consumed=0;produced=0
  for inp in sorted((OLD/slug).glob('reader-reference*.svg')):
   src=E.parse(inp).getroot();art=next((e for e in src if tag(e)=='svg'),None)
   if art is None:raise RuntimeError('No source art '+str(inp))
   groups=extract_groups(src)
   if not groups:raise RuntimeError('No annotated groups '+str(inp))
   consumed+=sum(len(g['contacts']) for g in groups)
   # One connector per side prevents merged locator trunks; no board coordinates are changed.
   for offset in range(0,len(groups),2):
    root=canvas(slug.replace('-',' ')+' · connector reference', 'Source-bound roles; native geometry unchanged. Electrical ratings and cable orientation remain unverified.')
    ax=float(art.get('x','0'));ay=float(art.get('y','0'));aw=float(art.get('width'));ah=float(art.get('height'));sc=min(800/aw,900/ah);tx=850-ax*sc;ty=190-ay*sc
    g=E.SubElement(root,'{'+NS+'}g',transform=f'translate({tx} {ty}) scale({sc})');g.append(copy.deepcopy(art))
    for side,group in enumerate(groups[offset:offset+2]):
     x=35 if side==0 else 1720;y=185
     for line in textwrap.wrap(group['heading'],44):root.append(txt(x,y,line,25));y+=32
     y+=20
     for k,s in group['contacts']:y+=pill(root,x,y,k,s);produced+=1
     if y>1200:raise RuntimeError('Panel overflow '+slug+':'+group['heading'])
     for px,py in group['locators']:
      px=tx+sc*px;py=ty+sc*py;end=x+745 if side==0 else x
      E.SubElement(root,'{'+NS+'}path',d=f'M{px} {py} L{end} 155',stroke='#a3aeb9',**{'stroke-width':'2','stroke-dasharray':'6 6','fill':'none'})
      E.SubElement(root,'{'+NS+'}circle',cx=str(px),cy=str(py),r='7',fill='none',stroke='#e7c86d')
    root.append(txt(35,1240,('Recovered historical board abstract; source registration and missing component artwork remain open.' if record['artwork_status']=='recovered_existing_abstract_candidate' else 'Source-derived pad/silk reconstruction; not populated hardware or canonical abstract artwork.'),22))
    root.extend([txt(35,1300,'Connector locators are annotation leaders, not electrical wires. Read native 0° contact companions for pad order.',24),txt(35,1340,'Original full source sheet and its circuit notes are retained unchanged in the frozen map; no new hardware or ratings inferred.',23)])
    files.append(save(root,OUT/slug/f'connector-reference-{len(files)+1:02}.svg'))
  if consumed!=produced:raise RuntimeError('Contact loss '+slug)
  records.append({'slug':slug,'source_record':record,'annotation_contacts_input':consumed,'annotation_contacts_output':produced,'files':files,'source_svg_files_unchanged':True,'native_placement_changed':False,'accepted':False})
 OUT.mkdir(exist_ok=True)
 (OUT/'layout-map.json').write_text(json.dumps({'source_map_sha256':hashlib.sha256((OLD/'integration-map.json').read_bytes()).hexdigest(),'records':records,'accepted':0,'actual_viewer_accepted':False},indent=2)+'\n')
 print(json.dumps({'type':'summary','records':len(records),'sheets':sum(len(r['files']) for r in records),'contacts':sum(r['annotation_contacts_output'] for r in records)}))

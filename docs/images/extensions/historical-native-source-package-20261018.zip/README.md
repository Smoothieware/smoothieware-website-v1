# Historical source-derived diagram source package

Prepared 2026-10-18 for A5984 stepper driver, C.H.I.P carrier and large Eagle MOSFET only. This editable source package accompanies the source-derived instructional diagrams. The native source files, root license and embedded notices are unchanged. Board-specific SOURCE-AND-MODIFICATIONS.md files provide public-purpose attribution text.

The diagram artwork is procedurally drawn from those exact native files; no separate imported SVG, raster or 3D component artwork is used. Native embedded footprint geometry remains subject to its original applicable notices. Arial/sans-serif fonts are referenced without embedding font files.

To reproduce the compact annotation layout from editable source SVGs using Python3 standard library:

```sh
python reflow_reader_panels.py
python reflow_native_details.py
```

Generated editable SVGs are written to reproduced/<board>/. The original inputs, complete native sources and delivered editable SVGs are preserved. Circuit-notes.svg files retain the exact source-backed explanatory notes and can be edited directly. The source geometry remains incomplete as populated board art; browser/electrical/physical acceptance stays open. Private audit hashes, review receipts and rights decisions are kept outside this package.

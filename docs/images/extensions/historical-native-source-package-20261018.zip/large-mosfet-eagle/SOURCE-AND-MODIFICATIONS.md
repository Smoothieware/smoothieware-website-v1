# large mosfet eagle — source-derived instructional diagrams

Native hardware source: [Smoothieboard2](https://github.com/Smoothieware/Smoothieboard2/blob/52ab340de33180a975b25f856c161993488e6ace/extensions/Large%20MOSFET/Large%20Mosfet.brd), revision `52ab340de33180a975b25f856c161993488e6ace`. The unmodified native source is provided in `native/`. The upstream root CERN Open Hardware Licence v1.2 is retained in `../LICENSE-CERN-OHL-1.2.txt`; embedded notices remain in the original source.

Diagram modifications dated 2026-10-18: extracted exact native copper, silk and courtyard geometry; translated native coordinates into SVG display coordinates; added source-backed connector/pin roles and segmented annotation pills; split dense references into readable panels; enlarged numbered native contact details without changing contact geometry; removed oversized non-contact reference text from enlarged crops. These are source-derived geometric illustrations, not populated canonical smoothie-diagrams abstracts. Missing housings and unresolved electrical/source limits remain identified in the diagrams.

Editable SVG inputs and Python layout scripts are included in the package root. Retain this notice, applicable original source notices and license text when distributing the source-derived diagrams. The large Eagle MOSFET source additionally retains SparkFun footprint-library descriptions stating Creative Commons ShareAlike4.0 International; see its EMBEDDED-NOTICES.json and the original board source. No endorsement or hardware qualification is implied.

Actual page/viewer readability, cable mating orientation, electrical ratings and physical operation are not accepted by this package. The required populated canonical board abstract remains unavailable.

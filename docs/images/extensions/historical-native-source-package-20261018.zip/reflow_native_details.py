"""Enlarge exact native source-detail crops; remove oversized reference text only inside geometry groups."""
from pathlib import Path
import copy,json,hashlib,xml.etree.ElementTree as E,re
from reflow_reader_panels import canvas,txt,save,NS,OLD,OUT,SLUGS,tag
records=[]
for slug in SLUGS:
 files=[]
 for p in sorted((OLD/slug).glob('*contact-details*.svg')):
  src=E.parse(p).getroot();w,h=map(float,src.get('viewBox').split()[2:]);heads=[]
  for e in src:
   if tag(e)!='text':continue
   s=e.text or '';y=float(e.get('y','0'))
   if 120<y<h-130 and ('native ' in s or ' · Top' in s or ' · F.Cu' in s or ' · B.Cu' in s or 'source board side' in s):heads.append((float(e.get('x')),y,s))
  if not heads:raise RuntimeError('No native panels '+str(p))
  xs=sorted(set(x for x,y,s in heads));ys=sorted(set(y for x,y,s in heads));cw=min([b-a for a,b in zip(xs,xs[1:])]or[w-70]);ch=min([b-a for a,b in zip(ys,ys[1:])]or[h-300])
  for parent in src.iter():
   for child in list(parent):
    if tag(child)=='text' and (child.text or '').startswith('Native copper/silk reconstruction is supplementary'):parent.remove(child)
  # C1/C4 use 0.7 mm native pads: place annotation badges outside copper.
  if slug == 'a5984-stepper-driver':
   active_reference = None
   children = list(src)
   for index, child in enumerate(children):
    if tag(child) == 'text' and ' · native ' in (child.text or ''):
     active_reference = (child.text or '').split(' · ')[0]
    if active_reference not in ['C1', 'C4'] or tag(child) != 'circle' or child.get('r') != '8':
     continue
    label = children[index + 1]
    assert tag(label) == 'text' and (label.text or '').isdigit()
    contact = int(label.text)
    px, py = float(child.get('cx')), float(child.get('cy'))
    direction = -1 if contact % 2 else 1
    bx = px + direction * 50
    child.set('cx', str(bx)); child.set('data-callout-for', active_reference + '.' + str(contact))
    label.set('x', str(bx - (8 if contact == 10 else 5)))
    leader = E.Element('{'+NS+'}path', {'d': f'M{px + direction*6} {py}L{bx-direction*9} {py}', 'stroke':'#e7c86d', 'stroke-width':'1.2', 'fill':'none', 'data-contact-leader':active_reference+'.'+str(contact)})
    src.insert(list(src).index(child), leader)
   for group in src.iter():
    if group.get('data-reference') in ['C1', 'C4']:
     for item in list(group):
      if tag(item) == 'text' and item.text == group.get('data-reference'):group.remove(item)
  # Non-contact silk references are expendable labels, not copper or source artwork.
  for g in src:
   if tag(g)!='g':continue
   for parent in g.iter():
    for child in list(parent):
     if tag(child)=='text' and re.fullmatch(r'(JP|J|RV|D|SW)\d+(?:-\d+)?',child.text or ''):parent.remove(child)
  for i in range(0,len(heads),2):
   root=canvas(slug.replace('-',' ')+' · enlarged native contact details','Exact native XY / 0° relative to source board; NOT a mating view. Missing pad shapes/housing remain explicit.')
   for side,(x,y,title) in enumerate(heads[i:i+2]):
    v=copy.deepcopy(src);v.set('viewBox',f'{x-8} {y-35} {cw-12} {ch-15}');v.set('x',str(35+side*1230));v.set('y','160');scale=min(1190/(cw-12),1090/(ch-15));vw=(cw-12)*scale;vh=(ch-15)*scale;v.set('overflow','hidden');v.set('width',str(vw));v.set('height',str(vh));clip_id='panel-'+str(side);defs=E.SubElement(root,'{'+NS+'}defs');clip=E.SubElement(defs,'{'+NS+'}clipPath',id=clip_id);E.SubElement(clip,'{'+NS+'}rect',x=str(35+side*1230),y='160',width=str(vw),height=str(vh));holder=E.SubElement(root,'{'+NS+'}g',**{'clip-path':'url(#'+clip_id+')'});holder.append(v)
   root.append(txt(35,1335,'Only the display scale changes. Source pad identity/positions and missing-art caveats are preserved; no physical acceptance.',23));files.append(save(root,OUT/slug/f'native-detail-{len(files)+1:02}.svg'))
 records.append({'slug':slug,'files':files,'accepted':False})
(OUT/'detail-layout-map.json').write_text(json.dumps({'records':records,'actual_viewer_accepted':False},indent=2)+'\n');print(json.dumps({'type':'summary','detail_sheets':sum(len(r['files'])for r in records)}))

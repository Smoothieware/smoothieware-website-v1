# Native-source and drawing notice

Board: extraendstops. Native source revision: 52ab340de33180a975b25f856c161993488e6ace.
Source-license evidence: CERN-OHL-1.2-native-source.

The native source and upstream notices are unmodified. The new documentation
drawing was created on 2026-10-18 by the Smoothieware documentation project
from the exact native pad and board-edge coordinates. It does not use copied
component illustrations. The drawing changes presentation, not the native CAD.
Retain this source bundle and upstream license/attribution with derivatives.

The drawing is a source-derived contact locator, not canonical populated-board
artwork or proof of fitted cavity numbering, electrical limits or hardware safety.
The required canonical abstract and actual viewer/hardware checks remain OPEN.

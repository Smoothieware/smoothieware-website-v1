# Native-source and drawing notice

Board: flambegate. Native source revision: 636f6ce4abb2750abbd326615f91eb67bd025ac0.
Source-license evidence: GPL-3.0-repository-notice-present.

The native source and upstream notices are unmodified. The new documentation
drawing was created on 2026-10-18 by the Smoothieware documentation project
from the exact native pad and board-edge coordinates. It does not use copied
component illustrations. The drawing changes presentation, not the native CAD.
Retain this source bundle and upstream license/attribution with derivatives.

The drawing is a source-derived contact locator, not canonical populated-board
artwork or proof of fitted cavity numbering, electrical limits or hardware safety.
The required canonical abstract and actual viewer/hardware checks remain OPEN.

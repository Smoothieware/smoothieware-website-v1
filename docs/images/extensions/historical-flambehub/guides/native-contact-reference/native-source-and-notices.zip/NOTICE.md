# Native-source and drawing notice

Board: flambehub. Native source revision: 02f355e19b2fc8b0a7baaca4e1a2e3b2ae2ffc71.
Source-license evidence: GPL-3.0-repository-notice-present.

The native source and upstream notices are unmodified. The new documentation
drawing was created on 2026-10-18 by the Smoothieware documentation project
from the exact native pad and board-edge coordinates. It does not use copied
component illustrations. The drawing changes presentation, not the native CAD.
Retain this source bundle and upstream license/attribution with derivatives.

The drawing is a source-derived contact locator, not canonical populated-board
artwork or proof of fitted cavity numbering, electrical limits or hardware safety.
The required canonical abstract and actual viewer/hardware checks remain OPEN.
